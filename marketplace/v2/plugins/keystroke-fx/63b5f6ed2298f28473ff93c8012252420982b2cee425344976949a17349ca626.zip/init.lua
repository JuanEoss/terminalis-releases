local M = {}
M.name        = "keystroke-fx"
M.version     = "1.0.0"
M.author      = "mwerner"
M.description = "Efectos visuales al escribir en la terminal."
M.permissions = {}
M.terminal_background = true

-- ── Catálogos ─────────────────────────────────────────────────────────────────

local EFFECTS = {
    { id = "sparks", label = "Partículas" },
    { id = "burst",  label = "Explosión radial" },
    { id = "rain",   label = "Lluvia Matrix" },
}

local PALETTES = {
    { id = "auto",    label = "Auto (tema)" },
    { id = "matrix",  label = "Matrix" },
    { id = "cyan",    label = "Cian" },
    { id = "amber",   label = "Ámbar" },
    { id = "magenta", label = "Magenta" },
    { id = "rainbow", label = "Arcoíris" },
}

local FIXED = {
    matrix  = { "#00FF41", "#39FF14", "#00FA9A", "#CCFFCC", "#ADFF2F" },
    cyan    = { "#00E5FF", "#18FFFF", "#84FFFF", "#00B8D4", "#B2EBF2" },
    amber   = { "#FFC400", "#FFD740", "#FFAB00", "#FFE57F", "#FF6D00" },
    magenta = { "#FF4081", "#F50057", "#FF80AB", "#EA80FC", "#D500F9" },
    rainbow = { "#FF5252", "#FFD740", "#69F0AE", "#40C4FF", "#E040FB" },
}

-- ── Config helpers ────────────────────────────────────────────────────────────

local function label_for(catalog, id)
    for _, it in ipairs(catalog) do if it.id == id then return it.label end end
    return catalog[1].label
end

local function id_for(catalog, label)
    for _, it in ipairs(catalog) do if it.label == label then return it.id end end
    return catalog[1].id
end

local function labels_of(catalog)
    local out = {}
    for _, it in ipairs(catalog) do table.insert(out, it.label) end
    return out
end

local function current_effect()  return terminalis.storage.get("effect")  or "sparks" end
local function current_palette() return terminalis.storage.get("palette") or "auto"   end
local function current_intensity()
    return tonumber(terminalis.storage.get("intensity") or "1") or 1
end
local function trails_enabled()
    return (terminalis.storage.get("trails") or "false") == "true"
end

local function safe_hex_color(value)
    if type(value) ~= "string" then return nil end
    if value:match("^#%x%x%x%x%x%x$") then
        return value
    end
    return nil
end

-- "auto" toma accent + brights del tema activo vía terminalis.theme()
local function palette_colors()
    local id = current_palette()
    if id ~= "auto" then return FIXED[id] or FIXED.matrix end
    local t = terminalis.theme()
    if not t then return FIXED.matrix end
    local a = t.ansi or {}
    local out = {}
    local candidates = { t.accent, a[11], a[15], a[13], t.fg }
    for i = 1, 5 do
        local safe = safe_hex_color(candidates[i])
        if safe then table.insert(out, safe) end
    end
    return #out > 0 and out or FIXED.matrix
end

-- ── Prólogo común ─────────────────────────────────────────────────────────────

local function prologue()
    local pal = {}
    for _, hex in ipairs(palette_colors()) do table.insert(pal, "'" .. hex .. "'") end
    return [[
<!DOCTYPE html><html><head><meta charset="utf-8">
<style>*{margin:0;padding:0}
html,body{width:100%;height:100%;overflow:hidden;background:transparent}
canvas{position:fixed;inset:0;pointer-events:none}</style>
<body><canvas id="c"></canvas><script>
const cv=document.getElementById('c'),cx=cv.getContext('2d');
let TX=0,TY=0,TW=0,TH=0;
function setTerminalRect(x,y,w,h){TX=x;TY=y;TW=w;TH=h;}
function resize(){cv.width=window.innerWidth||800;cv.height=window.innerHeight||600;}
resize();window.addEventListener('resize',resize);
function hexRgb(h){const n=parseInt(h.slice(1),16);return[(n>>16)&255,(n>>8)&255,n&255];}
const PAL=[]] .. table.concat(pal, ",") .. [[];
const PALRGB=PAL.map(hexRgb);
const INTENSITY=]] .. string.format("%.2f", current_intensity()) .. [[;
const TRAILS=]] .. tostring(trails_enabled()) .. [[;
function rgba(c,a){return 'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';}
function pick(){return PALRGB[Math.floor(Math.random()*PALRGB.length)];}
// TRAILS on → fade parcial en vez de borrar (deja estelas)
let raf=0,tail=0,alive=false;
const TAIL_FRAMES=40,FADE_BASE=0.12,FADE_PEAK=0.85;
// Con estelas el borrado es un 'destination-out' parcial. Un alpha fijo nunca llega
// a 0 real (el redondeo de 8 bits deja residuo clavado), asi que la fuerza del fade
// arranca suave y sube con curva cuadratica durante la cola: la estela se disuelve
// de verdad y el clearRect final no tiene nada que cortar.
function clearFrame(){
  if(!TRAILS){cx.clearRect(0,0,cv.width,cv.height);return;}
  const p=alive?0:1-tail/TAIL_FRAMES;
  const a=FADE_BASE+p*p*FADE_PEAK;
  cx.globalCompositeOperation='destination-out';
  cx.fillStyle='rgba(0,0,0,'+a+')';
  cx.fillRect(0,0,cv.width,cv.height);
  cx.globalCompositeOperation='source-over';
}
function endFrame(isAlive){
  alive=isAlive;
  if(isAlive){tail=TAIL_FRAMES;raf=requestAnimationFrame(draw);return;}
  if(TRAILS&&tail>0){tail--;raf=requestAnimationFrame(draw);return;}
  cx.clearRect(0,0,cv.width,cv.height);
  raf=0;
}
]]
end

local EPILOGUE = "\n</script></body></html>\n"

-- ── Partículas: saltan hacia arriba ───────────────────────────────────────────
local function html_sparks()
    return prologue() .. [[
const GRAVITY=0.075,FADEOUT=0.96;
const parts=[];
function draw(){
  clearFrame();
  for(const p of parts){
    p.vy+=GRAVITY;p.x+=p.vx;p.y+=p.vy;p.alpha*=FADEOUT;
    cx.fillStyle=rgba(p.c,p.alpha);
    cx.fillRect(Math.round(p.x-1),Math.round(p.y-1),3,3);
  }
  for(let i=parts.length-1;i>=0;i--)if(parts[i].alpha<0.1)parts.splice(i,1);
  endFrame(parts.length>0);
}
function spawn(x,y){
  const n=Math.max(1,Math.round((5+Math.random()*5)*INTENSITY));
  for(let i=0;i<n;i++)
    parts.push({x:x,y:y,vx:-1+Math.random()*2,vy:-3.5+Math.random()*2,
                alpha:1,c:PALRGB[i%PALRGB.length]});
  if(raf===0)raf=requestAnimationFrame(draw);
}
]] .. EPILOGUE
end

-- ── Explosión radial ──────────────────────────────────────────────────────────
local function html_burst()
    return prologue() .. [[
const GRAVITY=0.04,FADEOUT=0.93,DRAG=0.97;
const parts=[];
function draw(){
  clearFrame();
  for(const p of parts){
    p.vx*=DRAG; p.vy=p.vy*DRAG+GRAVITY;
    p.x+=p.vx; p.y+=p.vy; p.alpha*=FADEOUT;
    cx.fillStyle=rgba(p.c,p.alpha);
    cx.fillRect(Math.round(p.x-p.size/2),Math.round(p.y-p.size/2),p.size,p.size);
  }
  for(let i=parts.length-1;i>=0;i--)if(parts[i].alpha<0.08)parts.splice(i,1);
  endFrame(parts.length>0);
}
function spawn(x,y){
  const n=Math.max(3,Math.round((10+Math.random()*6)*INTENSITY));
  for(let i=0;i<n;i++){
    const ang=(i/n)*Math.PI*2+Math.random()*0.5;
    const spd=1.2+Math.random()*2.6;
    parts.push({x:x,y:y,vx:Math.cos(ang)*spd,vy:Math.sin(ang)*spd,
                alpha:1,size:2+Math.round(Math.random()*2),c:pick()});
  }
  if(raf===0)raf=requestAnimationFrame(draw);
}
]] .. EPILOGUE
end

-- ── Lluvia Matrix: confinada al rect del terminal ─────────────────────────────
local function html_rain()
    return prologue() .. [[
const CHARS='アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン0123456789';
const FS=14,FALL=2.2,FADE=0.03;
const LEN=Math.max(4,Math.round(10*INTENSITY));
const cols=[];
function rc(){return CHARS[Math.floor(Math.random()*CHARS.length)];}
function draw(){
  clearFrame();
  cx.font=FS+'px monospace';
  const bottom=TH>0?TY+TH:cv.height;
  for(const c of cols){
    c.y+=FALL;
    if(c.growing){c.len=Math.min(c.len+FALL/FS,LEN);if(c.len>=LEN)c.growing=false;}
    else{c.opacity-=FADE;}
    const n=Math.floor(c.len);
    for(let i=0;i<n;i++){
      const cy=c.y+i*FS;
      if(cy>bottom)break;
      const hf=i/Math.max(n-1,1);
      const a=c.opacity*(i===n-1?1:0.15+(1-hf)*0.5);
      cx.fillStyle=i===n-1?'rgba(235,255,235,'+a+')':rgba(c.c,a);
      cx.fillText(c.chars[i],c.x,cy);
    }
  }
  for(let i=cols.length-1;i>=0;i--)if(cols[i].opacity<=0)cols.splice(i,1);
  endFrame(cols.length>0);
}
function spawn(x,y){
  cols.push({x:x,y:y,len:0,chars:Array.from({length:LEN},rc),
             opacity:1,growing:true,c:pick()});
  if(raf===0)raf=requestAnimationFrame(draw);
}
]] .. EPILOGUE
end

-- ── Hooks ─────────────────────────────────────────────────────────────────────

function M.on_load()
    terminalis.background.show()
    -- Sin status item: el efecto ya es su propia señal visual.
end

function M.on_unload()
    terminalis.background.hide()
    terminalis.status.clear()
end

function M.on_keypress(ctx)
    if #ctx.command ~= 1 then return end
    if string.byte(ctx.command, 1) < 32 then return end
    if ctx.cursor_x < 0 then return end
    terminalis.background.eval(
        string.format("spawn(%.1f,%.1f)", ctx.cursor_x, ctx.cursor_y))
end

function M.background_content()
    local e = current_effect()
    if e == "rain"  then return ui.webview(html_rain())  end
    if e == "burst" then return ui.webview(html_burst()) end
    return ui.webview(html_sparks())
end

-- ── Settings UI ───────────────────────────────────────────────────────────────

function M.settings_content()
    return {
        ui.picker("Efecto", {
            options   = labels_of(EFFECTS),
            value     = label_for(EFFECTS, current_effect()),
            on_change = "set_effect",
        }),
        ui.picker("Color", {
            options   = labels_of(PALETTES),
            value     = label_for(PALETTES, current_palette()),
            on_change = "set_palette",
        }),
        ui.separator(),
        ui.slider("Intensidad", {
            value = current_intensity(), min = 0.4, max = 2.5, step = 0.1,
            on_change = "set_intensity",
        }),
        ui.toggle("Estelas", {
            value = trails_enabled(), icon = "wind",
            on_change = "set_trails",
        }),
    }
end

local function apply()
    terminalis.background.reload()
end

function M.set_effect(ctx)
    terminalis.storage.set("effect", id_for(EFFECTS, ctx.value))
    apply()
end

function M.set_palette(ctx)
    terminalis.storage.set("palette", id_for(PALETTES, ctx.value))
    apply()
end

function M.set_intensity(ctx)
    terminalis.storage.set("intensity", ctx.value)
    apply()
end

function M.set_trails(ctx)
    terminalis.storage.set("trails", ctx.value)
    apply()
end

return M
