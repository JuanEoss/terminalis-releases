local M = {}

M.name = "terminal-pet"
M.version = "1.0.0"
M.author = "mwerner"
M.description = "Una mascota animada que reacciona a tu actividad en Terminalis."
M.permissions = {}
M.terminal_background = true

-- Atlas Codex Pets: 8 columnas por 9 filas, una fila por estado. El arte viene
-- a 192x208 por celda y se reduce a 1/4 al importarlo, un divisor exacto.
local CELL_W, CELL_H = 48, 52

-- Cada pet declara en `anims` lo que difiere de la tabla base. El sueño va
-- siempre acá porque la spec no define una fila para dormir, y `failed` no
-- siempre sirve: en Pikachu esa fila lo muestra cargando electricidad, no
-- derrotado, y el que duerme acostado es un cuadro de `waiting`.
local PETS = {
    ["Azure"]     = { sheet = "azure.png",
                      anims = { sleep = { row = 5, first = 3, frames = 2, fps = 1 } } },
    ["Meowbyte"]  = { sheet = "meowbyte.png",
                      anims = { sleep = { row = 5, first = 5, frames = 1, fps = 1 } } },
    ["Bulwark"]   = { sheet = "bulwark.png",
                      anims = { sleep = { row = 5, first = 4, frames = 1, fps = 1 } } },
    -- Franky trae las filas de caminata intercambiadas respecto de la spec: su
    -- fila 1 mira a la izquierda y la 2 a la derecha, al revés que el resto.
    ["Franky"]    = { sheet = "franky.png", flipped_walk = true,
                      anims = { sleep = { row = 5, first = 3, frames = 1, fps = 1 } } },
    -- GOAT Leo y Dude no se echan nunca: sus cuadros más horizontales dan 0.73
    -- y 0.82 contra 1.2-1.7 del resto, así que duermen encorvados.
    ["GOAT Leo"]  = { sheet = "goat-leo.png",
                      anims = { sleep = { row = 5, first = 3, frames = 1, fps = 1 } } },
    ["Dude"]      = { sheet = "dude.png",
                      anims = { sleep = { row = 5, first = 4, frames = 1, fps = 1 } } },
    ["Paperclip"] = { sheet = "paperclip.png",
                      anims = { sleep = { row = 5, first = 3, frames = 1, fps = 1 } } },
    ["Cinder"]    = { sheet = "cinder.png",
                      anims = { sleep = { row = 5, first = 3, frames = 2, fps = 1 } } },
    ["Swag"]      = { sheet = "swag.png",
                      anims = { sleep = { row = 5, first = 5, frames = 2, fps = 1 } } },
    -- Pikachu es el más distinto: no tiene caminata a la derecha (su fila 2
    -- mezcla perfil con cuadros frontales), su `failed` lo muestra cargando
    -- electricidad de pie, y el que duerme acostado es `waiting`.
    ["Pikachu"]   = { sheet = "pikachu.png", mirror_walk = true,
                      anims = {
                          working = { row = 5, first = 0, frames = 8, fps = 8 },
                          failure = { row = 6, first = 4, frames = 2, fps = 4, loop = false },
                          sleep   = { row = 6, first = 1, frames = 2, fps = 1 },
                      } },
}

-- Procesos que se quedan en primer plano y no emiten un comando por cada cosa
-- que hacés. Adentro de una de estas, `on_command` se dispara una sola vez al
-- entrar, así que el pet se queda ciego a toda la sesión.
local INTERACTIVE = {
    claude = true, codex = true, aider = true, gemini = true, opencode = true,
    vim = true, nvim = true, nano = true, emacs = true,
    top = true, htop = true, less = true, man = true, lazygit = true,
    python = true, node = true, irb = true, psql = true,
}

local PET_ORDER = { "Azure", "Meowbyte", "Bulwark", "Franky", "GOAT Leo", "Dude", "Paperclip", "Cinder", "Swag", "Pikachu" }

local ANIMS = {
    idle    = { row = 0, first = 0, frames = 6, fps = 5 },
    right   = { row = 1, first = 0, frames = 8, fps = 12 },
    left    = { row = 2, first = 0, frames = 8, fps = 12 },
    hello   = { row = 3, first = 0, frames = 4, fps = 8 },
    success = { row = 4, first = 0, frames = 5, fps = 10 },
    failure = { row = 5, first = 0, frames = 8, fps = 9, loop = false },
    working = { row = 6, first = 0, frames = 6, fps = 6 },
    -- `review` (fila 8) es una pose de atención: sirve para cuando escribís.
    -- La fila 7 (`running`) queda sin usar a propósito: está dibujada mirando
    -- sólo hacia un lado, así que en los traslados a la derecha el pet correría
    -- de espaldas.
    look    = { row = 8, first = 0, frames = 6, fps = 7 },
}

-- ─── Voz ──────────────────────────────────────────────────────────────────
-- Un banco de frases con variación, memoria corta y silencios. La gracia no
-- está en tener muchas frases sino en no repetir, no hablar siempre y que lo
-- que diga dependa de lo que acaba de pasar.

local VOICE = {
    -- Éxito, según cuánto costó
    quick     = { "listo", "fácil", "ya está", "obvio" },
    normal    = { "salió", "listo!", "bien ahí", "ahí está" },
    slow      = { "por fin!", "uf, salió", "costó eh", "al fin" },
    recovered = { "ahora sí", "esa era", "lo arreglaste", "ahí está" },

    -- Rachas
    streak3   = { "tres seguidas", "vas bien", "en llamas" },
    streak5   = { "racha x5!", "imparable", "cinco al hilo" },
    streak10  = { "diez seguidas!!", "sos una máquina" },

    -- Errores, escalando
    fail1     = { "ouch", "uh", "nop", "casi" },
    fail2     = { "otra vez...", "de nuevo?", "mmm" },
    fail3     = { "tres veces ya", "probá otra cosa", "algo anda mal" },
    failMany  = { "che, un respiro", "tomate un mate", "hora de un descanso" },

    -- Por categoría de comando
    test      = { "a ver esos tests", "cruzo los dedos" },
    build     = { "compilando…", "esto tarda" },
    deploy    = { "uy, deploy", "suerte con eso", "modo serio" },
    git       = { "git…", "commiteando" },

    testFail  = { "tests en rojo", "algo se rompió" },
    buildFail = { "no compila", "revisá el build" },
    deployFail= { "deploy caído", "uh, el deploy no" },

    -- Ocio e inactividad
    bored     = { "…", "zzz?", "seguís ahí?", "me aburro" },
    longIdle  = { "hace rato que nada", "¿café?", "silencio total" },
    welcome   = { "buenas!", "arrancamos?", "hola de nuevo" },
    farewell  = { "chau!", "hasta luego", "nos vemos", "volvé pronto" },
    farewellLong = { "qué sesión eh", "buen laburo", "descansá" },
    backAfter = { "ah, volviste", "te extrañé", "seguimos" },

    -- Momento del día
    lateNight = { "es tardísimo", "andá a dormir", "mañana también existe" },
    earlyBird = { "temprano eh", "buen día" },
}

local last_said = {}

-- Elige una frase distinta de la última que se dijo para esa misma situación.
-- Repetir es lo que hace que se note el truco.
local function pick(bucket)
    local options = VOICE[bucket]
    if not options or #options == 0 then return nil end
    if #options == 1 then return options[1] end
    -- Acotado a propósito: un `repeat ... until` sin tope se cuelga si el grupo
    -- tuviera todas sus frases iguales, y esto corre en la cola de Lua, así que
    -- colgaría todos los plugins, no sólo el pet.
    local choice = options[math.random(#options)]
    for _ = 1, 4 do
        if choice ~= last_said[bucket] then break end
        choice = options[math.random(#options)]
    end
    last_said[bucket] = choice
    return choice
end


-- ─── Memoria ──────────────────────────────────────────────────────────────
-- Vive en RAM y dura lo que dure la sesión. No se persiste nada: al plugin no
-- le interesa tu historial, sólo el rato que estuvieron juntos.
local mem = {
    fails = 0,            -- errores seguidos
    last_fail_kind = nil, -- categoría del último error, para notar la repetición
    running_kind = nil,     -- categoría del comando en curso
    greeted = false,
    last_activity = os.time(),
    busy_since = nil,       -- cuándo arrancó la ráfaga de salida en curso
    busy_last = 0,          -- último aviso de salida, para cortar ráfagas huérfanas
    pending_work = 0,       -- segundos de trabajo aún sin cerrar
    streak_said = nil,      -- último hito ya cantado, para no repetirlo
    last_result = 0,        -- cuándo informó el shell un exit code de verdad
    idle_stage = 0,       -- 0 nada dicho, 1 aburrido, 2 hace rato
    was_asleep = false,
}

local function touch()
    mem.last_activity = os.time()
    if mem.idle_stage == 0 and not mem.was_asleep then return nil end
    -- Volver después de dormir merece frase; volver de un simple aburrimiento
    -- sólo reinicia los escalones.
    local line = mem.was_asleep and pick("backAfter") or nil
    mem.idle_stage = 0
    mem.was_asleep = false
    return line
end

-- Frase para un comando que arranca. La mayoría de las veces calla: un pet que
-- comenta cada `ls` cansa a los dos minutos.
local function line_for_start(kind)
    if kind == "deploy" then return pick("deploy") end
    if kind == "test"  and math.random() < 0.75 then return pick("test") end
    if kind == "build" and math.random() < 0.65 then return pick("build") end
    if kind == "git"   and math.random() < 0.4 then return pick("git") end
    return nil
end

-- Frase para un comando que terminó. El orden importa: lo más específico
-- primero, y la intensidad acompaña a lo que costó.
local function line_for_finish(ok, kind, duration_ms, streak)
    if not ok then
        mem.fails = (kind == mem.last_fail_kind) and mem.fails + 1 or 1
        mem.last_fail_kind = kind
        if mem.fails >= 5 then return pick("failMany") end
        if mem.fails == 3 then return pick("fail3") end
        if mem.fails == 2 then return pick("fail2") end
        if kind == "test"   then return pick("testFail") end
        if kind == "build"  then return pick("buildFail") end
        if kind == "deploy" then return pick("deployFail") end
        return pick("fail1")
    end

    local recovering = mem.fails > 0
    mem.fails = 0
    mem.last_fail_kind = nil

    -- Los hitos se cantan una vez. Sin esto, dos caminos distintos podían
    -- anunciar la misma racha y parecía que el pet se repetía.
    local milestone = streak >= 10 and "streak10"
        or streak == 5 and "streak5"
        or streak == 3 and "streak3"
        or nil
    -- Se recuerda el hito y no el número: como el de 10 es un `>=`, cada éxito a
    -- partir del décimo traía un número distinto y volvía a cantar lo mismo.
    if milestone and milestone ~= mem.streak_said then
        mem.streak_said = milestone
        return pick(milestone)
    end
    if recovering   then return pick("recovered") end
    if duration_ms >= 30000 then return pick("slow") end
    -- Lo instantáneo casi nunca merece comentario.
    if duration_ms < 1500 then
        return math.random() < 0.35 and pick("quick") or nil
    end
    return math.random() < 0.7 and pick("normal") or nil
end

-- Saludo de la primera vez, con la hora como excusa.
local function line_for_greeting()
    if mem.greeted then return nil end
    mem.greeted = true
    local hour = tonumber(os.date("%H")) or 12
    if hour >= 1 and hour < 6 then return pick("lateNight") end
    if hour >= 6 and hour < 9 then return pick("earlyBird") end
    return pick("welcome")
end

local function clamp(value, minimum, maximum)
    return math.min(maximum, math.max(minimum, value))
end

local function stored_number(key, default, minimum, maximum)
    local value = tonumber(terminalis.storage.get(key)) or default
    return clamp(value, minimum, maximum)
end

local function stored_bool(key, default)
    local value = terminalis.storage.get(key)
    if value == nil then return default end
    return value == true or value == "true" or value == 1
end

-- Luminancia percibida, para elegir un contorno que contraste con el texto.
local function luminance(hex)
    local r = tonumber(hex:sub(2, 3), 16) or 0
    local g = tonumber(hex:sub(4, 5), 16) or 0
    local b = tonumber(hex:sub(6, 7), 16) or 0
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255
end

local function safe_hex(value, fallback)
    if type(value) == "string" and value:match("^#%x%x%x%x%x%x$") then
        return value
    end
    return fallback
end

-- Dónde vive el pet, como fracción del ancho útil. No se puede arrastrar: el
-- fondo es una ventana con `ignoresMouseEvents`, y sacárselo le comería los
-- clics al terminal.
local function home_position()
    return stored_number("home_x", 0.05, 0.0, 1.0)
end

local function pet_name()
    local stored = terminalis.storage.get("pet")
    if type(stored) == "string" and PETS[stored] then return stored end
    return PET_ORDER[1]
end

local function current_pet()
    return PETS[pet_name()]
end

local function pet_size()
    return stored_number("size", 1.4, 0.7, 1.6)
end

local function sleep_seconds()
    return stored_number("sleep_seconds", 30, 10, 120)
end

-- El rect del terminal es informativo: la app lo publica para que los fondos
-- sepan dónde empieza y termina, pero el plugin decide si se queda adentro.
-- A la izquierda del terminal suele haber más piso libre.
local function roam_whole_window()
    return stored_bool("roam_window", true)
end

local function bubbles_enabled()
    return stored_bool("bubbles", true)
end

-- Serializa el atlas como literales JS. Todo sale de constantes del plugin,
-- nunca de entrada del usuario.
local function js_anims()
    -- Base más lo que el personaje declare distinto.
    local merged = {}
    for name, anim in pairs(ANIMS) do merged[name] = anim end
    for name, anim in pairs(current_pet().anims or {}) do merged[name] = anim end

    local parts = {}
    for name, anim in pairs(merged) do
        parts[#parts + 1] = string.format(
            "%s:{row:%d,first:%d,frames:%d,fps:%.2f,loop:%s}",
            name, anim.row, anim.first, anim.frames, anim.fps,
            anim.loop == false and "false" or "true"
        )
    end
    table.sort(parts)
    return "{" .. table.concat(parts, ",") .. "}"
end

local function html()
    local theme = terminalis.theme()
    local outline = safe_hex(theme and theme.terminal_fg, "#E8E8EE")
    -- Contorno opuesto al texto, no del color del fondo: el pet puede estar
    -- sobre el terminal, sobre el explorador o encima de texto, y un contorno
    -- del fondo desaparece justo cuando hace falta.
    local halo = luminance(outline) > 0.5 and "#101014" or "#F4F4F8"

    return [[<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { box-sizing: border-box; }
  html, body { margin: 0; width: 100%; height: 100%; overflow: hidden; background: transparent; }
  canvas { position: fixed; inset: 0; width: 100%; height: 100%; pointer-events: none; image-rendering: pixelated; }
</style>
</head>
<body>
<canvas id="pet-canvas" aria-hidden="true"></canvas>
<script>
(() => {
  'use strict';

  const canvas = document.getElementById('pet-canvas');
  const ctx = canvas.getContext('2d', { alpha: true });
  const OUTLINE = ']] .. outline .. [[';
  const HALO = ']] .. halo .. [[';
  const SCALE_SETTING = ]] .. string.format("%.2f", pet_size()) .. [[;
  const SLEEP_AFTER = ]] .. string.format("%.0f", sleep_seconds() * 1000) .. [[;
  const SHOW_BUBBLES = ]] .. tostring(bubbles_enabled()) .. [[;
  const ROAM_WINDOW = ]] .. tostring(roam_whole_window()) .. [[;
  const HOME_POS = ]] .. string.format("%.3f", home_position()) .. [[;
  const EDGE = 20;
  const CELL_W = ]] .. CELL_W .. [[;
  const CELL_H = ]] .. CELL_H .. [[;
  const ANIM = ]] .. js_anims() .. [[;
  const FLIPPED_WALK = ]] .. tostring(current_pet().flipped_walk == true) .. [[;
  // Con una sola fila de caminata usable no hay más remedio que espejarla.
  const MIRROR_WALK = ]] .. tostring(current_pet().mirror_walk == true) .. [[;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // El WebView del fondo resuelve rutas relativas dentro del directorio del
  // plugin. Si el sheet falta, `ready` queda en false y no se dibuja nada.
  const sheet = new Image();
  sheet.ready = false;
  sheet.onload = () => { sheet.ready = true; };
  sheet.src = ']] .. current_pet().sheet .. [[';

  let dpr = 1;
  let width = 0;
  let height = 0;
  let terminal = { x: 0, y: 0, w: 0, h: 0 };
  let petX = 0;
  let targetX = 0;
  let state = 'hello';
  let stateStarted = performance.now();
  let stateUntil = stateStarted + 1400;
  let lastActive = stateStarted;
  let facing = HOME_POS < 0.5 ? 1 : -1;
  let cursorX = 0;
  let bubble = '';
  let bubbleUntil = 0;
  let lastFrame = 0;
  // Hasta que la app no manda el rect del terminal, `bounds()` cae a la ventana
  // entera y el pet se ubicaría sobre el explorador. Se espera un poco antes de
  // dibujar nada; si el rect nunca llega, igual aparece.
  let hasTerminalRect = false;
  // Zona pintada en el cuadro anterior. Borrar la ventana entera costaba unos
  // 138 Mpx/s con una pantalla grande; el pet ocupa menos de la centésima parte.
  let dirty = null;
  const RECT_GRACE = 800;
  const startedAt = performance.now();
  let nextIdleAction = stateStarted + 4500;

  const allowedReactions = new Set(['walk', 'hello']);
  // Mientras dura una reacción el pet se planta: festejar o caerse en pleno
  // traslado se veía como un salto de costado. El destino no se pierde, sólo
  // se posterga, y el viaje sigue cuando la reacción termina.
  const STOPS_TO_REACT = new Set(['success', 'failure', 'hello']);
  const allowedTasks = new Set(['command', 'git', 'test', 'build', 'deploy']);
  const allowedResults = new Set(['success', 'failure']);
  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = Math.max(1, window.innerWidth);
    height = Math.max(1, window.innerHeight);
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    dirty = null;   // el lienzo cambió de tamaño: hay que borrarlo entero
    targetX = homeX();
    if (!Number.isFinite(petX) || petX === 0) petX = targetX;
  }

  function bounds() {
    if (ROAM_WINDOW) return { x: 0, y: 0, w: width, h: height };
    if (terminal.w > 80 && terminal.h > 60) return terminal;
    return { x: 0, y: 0, w: width, h: height };
  }

  function spriteWidth() {
    return CELL_W * SCALE_SETTING;
  }

  function spriteHeight() {
    return CELL_H * SCALE_SETTING;
  }

  // Amplitud de saltos y aplastados, atada a la altura real del pet: un salto
  // de 1px se lee en un sprite chico y desaparece en uno grande.
  function motionUnit() {
    return Math.max(2, spriteHeight() / 8);
  }

  function walkRange() {
    const area = bounds();
    const min = area.x + EDGE;
    const max = Math.max(min, area.x + area.w - spriteWidth() - EDGE);
    return { min, max, span: max - min };
  }

  function homeX() {
    const r = walkRange();
    return r.min + r.span * HOME_POS;
  }

  // Distancias como fracción del ancho disponible: en píxeles fijos, en una
  // ventana ancha el paseo era un pasito de nada. Y elige lado al azar en vez
  // de tirar siempre para el mismo, rebotando si no hay lugar.
  function patrolX(minFraction, maxFraction) {
    const r = walkRange();
    const distance = r.span * (minFraction + Math.random() * (maxFraction - minFraction));
    const direction = Math.random() < 0.5 ? -1 : 1;
    let target = homeX() + direction * distance;
    if (target < r.min || target > r.max) target = homeX() - direction * distance;
    return Math.max(r.min, Math.min(r.max, target));
  }

  function floorY() {
    const area = bounds();
    return area.y + area.h - 14;
  }

  window.setTerminalRect = function setTerminalRect(x, y, w, h) {
    if (![x, y, w, h].every(Number.isFinite)) return;
    terminal = { x, y, w: Math.max(0, w), h: Math.max(0, h) };
    targetX = homeX();
    // El primer rect corrige dónde vive el pet, no es un traslado: sin esto
    // cruzaba caminando desde el borde de la ventana hasta el terminal.
    if (!hasTerminalRect || state === 'idle' || state === 'sleep') {
      petX = targetX;
      dirty = null;   // salta de lugar: el área vieja no cubre la nueva
    }
    hasTerminalRect = true;
  };

  window.terminalPet = Object.freeze({
    look(nextCursorX) {
      if (!Number.isFinite(nextCursorX)) return;
      const now = performance.now();
      lastActive = now;
      cursorX = nextCursorX;
      facing = cursorX >= petX + spriteWidth() / 2 ? 1 : -1;
      // Escribir saca al pet de la espera: si te respondieron, ya está.
      // Trabajando no se interrumpe: mientras corre un comando seguís
      // escribiendo y el pet tiene que seguir trabajando.
      if (state === 'working') return;
      if (state !== 'look') stateStarted = now;
      state = 'look';
      stateUntil = now + 900;
    },
    react(kind) {
      if (!allowedReactions.has(kind)) return;
      const now = performance.now();
      lastActive = now;
      state = kind;
      stateStarted = now;
      stateUntil = now + (kind === 'walk' ? 1800 : 1050);
      if (kind === 'walk') {
        targetX = patrolX(0.15, 0.45);
        facing = targetX >= petX ? 1 : -1;
      } else {
        targetX = homeX();
      }
    },
    // Pulso de actividad del terminal. No trae texto ni sabe quién escribe, así
    // que no pisa una reacción en curso y se renueva sola: si la salida se
    // corta, el trabajo caduca sin necesidad de que nadie avise que terminó.
    // Única entrada de texto del canvas. El canvas anima y el plugin habla:
    // cuando ambos armaban frases se pisaban entre sí. El texto siempre sale
    // del banco del plugin, nunca de algo que hayas escrito vos.
    say(text) {
      if (!SHOW_BUBBLES || typeof text !== 'string' || !text) return;
      const now = performance.now();
      bubble = text.slice(0, 28);
      bubbleUntil = now + 1400 + Math.min(1200, text.length * 45);
    },
    activity() {
      const now = performance.now();
      lastActive = now;
      if (['success', 'failure', 'hello'].includes(state)) return;
        if (state === 'working') {
        stateUntil = Math.max(stateUntil, now + 4000);
        return;
      }
      state = 'working';
      stateStarted = now;
      stateUntil = now + 4000;
    },
    start(kind) {
      if (!allowedTasks.has(kind)) return;
      const now = performance.now();
      lastActive = now;
      state = 'working';
      stateStarted = now;
      stateUntil = now + 600000;
      targetX = homeX();
    },
    finish(result, durationMs, streak) {
      if (!allowedResults.has(result)) return;
      if (!Number.isFinite(durationMs) || !Number.isFinite(streak)) return;
      const now = performance.now();
      lastActive = now;
      state = result;
      stateStarted = now;
      stateUntil = now + (result === 'success' ? 1700 : 2200);
      targetX = homeX();
      // Acá no se arma ninguna frase: el canvas anima y el plugin habla. Este
      // bloque venía del diseño viejo y competía con el banco de frases —
      // escribía "racha xN" por su cuenta, sin pasar por la guarda de hitos.
    },
  });

  function walkSpeed() {
    return spriteWidth() * (reducedMotion ? 0.5 : 1.1);
  }

  // Hay traslado real en curso, sin importar en qué estado esté el pet.
  function isTravelling() {
    return Math.abs(targetX - petX) > Math.max(2, spriteWidth() * 0.06);
  }

  function update(now, dt) {
    if (now > stateUntil && state !== 'sleep') {
      state = now - lastActive >= SLEEP_AFTER ? 'sleep' : 'idle';
      stateStarted = now;
      targetX = homeX();
    }
    if (state !== 'sleep' && state !== 'working' && now - lastActive >= SLEEP_AFTER) {
      state = 'sleep';
      stateStarted = now;
      targetX = homeX();
      bubble = '';
    }
    if (state === 'idle' && now >= nextIdleAction && now - lastActive < SLEEP_AFTER - 2500) {
      targetX = patrolX(0.06, 0.28);
      facing = targetX >= petX ? 1 : -1;
      state = 'wander';
      stateStarted = now;
      stateUntil = now + 1400 + Math.random() * 900;
      nextIdleAction = now + 5000 + Math.random() * 6000;
    }
    // Velocidad constante, no interpolación exponencial: el paso está dibujado
    // cuadro a cuadro y con velocidad variable el pet patina sobre su animación.
    const delta = targetX - petX;
    if (!STOPS_TO_REACT.has(state)) {
      const step = walkSpeed() * (dt / 1000);
      petX += Math.abs(delta) <= step ? delta : Math.sign(delta) * step;
    }
    if (isTravelling()) facing = delta >= 0 ? 1 : -1;
  }

  function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
  }

  // Globo de historieta: cuerpo redondeado y cola apuntando al pet.
  function drawBubble(x, y, now) {
    if (!bubble || now >= bubbleUntil) return;
    ctx.save();
    ctx.font = '600 11px ui-monospace, Menlo, monospace';
    ctx.textBaseline = 'middle';

    const padding = 9;
    const boxW = Math.ceil(ctx.measureText(bubble).width) + padding * 2;
    const boxH = 21;
    const tail = 7;
    const radius = 8;
    const centerX = x + spriteWidth() / 2;
    const boxX = Math.round(centerX - boxW / 2);
    const boxY = Math.round(y - boxH - tail - 6);
    // La cola se mantiene dentro del cuerpo aunque el globo sea angosto.
    const tipX = Math.round(clamp(centerX, boxX + radius + 6, boxX + boxW - radius - 6));
    const right = boxX + boxW;
    const bottom = boxY + boxH;

    ctx.beginPath();
    ctx.moveTo(boxX + radius, boxY);
    ctx.lineTo(right - radius, boxY);
    ctx.quadraticCurveTo(right, boxY, right, boxY + radius);
    ctx.lineTo(right, bottom - radius);
    ctx.quadraticCurveTo(right, bottom, right - radius, bottom);
    ctx.lineTo(tipX + 5, bottom);
    ctx.lineTo(tipX - 1, bottom + tail);
    ctx.lineTo(tipX - 5, bottom);
    ctx.lineTo(boxX + radius, bottom);
    ctx.quadraticCurveTo(boxX, bottom, boxX, bottom - radius);
    ctx.lineTo(boxX, boxY + radius);
    ctx.quadraticCurveTo(boxX, boxY, boxX + radius, boxY);
    ctx.closePath();

    ctx.fillStyle = '#F7F5EF';
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#15151A';
    ctx.stroke();

    ctx.fillStyle = '#15151A';
    ctx.fillText(bubble, boxX + padding, boxY + boxH / 2);
    ctx.restore();
  }

  // Qué fila del atlas corresponde a lo que el pet está haciendo. Caminar tiene
  // los dos perfiles dibujados, así que gira cambiando de fila en vez de
  // espejarse.
  function currentAnim() {
    if (state === 'sleep') return ANIM.sleep;
    // Reacciones cortas: son el evento en sí, ganan aunque se esté moviendo.
    if (state === 'hello') return ANIM.hello;
    if (state === 'success') return ANIM.success;
    if (state === 'failure') return ANIM.failure;
    // Trasladarse gana sobre los estados de fondo. `working` se enciende con
    // cualquier salida del terminal y `look` con cada tecla, así que si fueran
    // primero el pet volvería a su rincón deslizándose en pose de espera.
    if (isTravelling()) {
      // Su fila buena mira a la izquierda; para ir a la derecha se espeja.
      if (MIRROR_WALK) return ANIM.right;
      const goingLeft = FLIPPED_WALK ? facing >= 0 : facing < 0;
      return goingLeft ? ANIM.left : ANIM.right;
    }
    if (state === 'working') return ANIM.working;
    if (state === 'look') return ANIM.look;
    return ANIM.idle;
  }

  function animFrame(anim, elapsed, now) {
    if (reducedMotion) return anim.first;
    // Las que ciclan van contra el reloj continuo. Si arrancaran en cada cambio
    // de estado, el paso se reiniciaría al pasar de paseo a vuelta a casa.
    const step = Math.floor(((anim.loop ? now : elapsed) / 1000) * anim.fps);
    // Sin loop la animación se queda en el último cuadro: `failure` termina con
    // el pet en el piso y repetirla lo haría levantarse y caerse en bucle.
    const index = anim.loop ? step % anim.frames : Math.min(step, anim.frames - 1);
    return anim.first + index;
  }

  function drawSprite(x, y, anim, elapsed, now) {
    if (!sheet.ready) return;
    const frame = animFrame(anim, elapsed, now);
    const smoothing = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    // Sólo se espeja al personaje que no tiene la otra dirección dibujada, y
    // sólo mientras camina hacia ese lado.
    const mirrored = MIRROR_WALK && isTravelling() && facing > 0;
    if (mirrored) {
      ctx.save();
      ctx.translate(Math.round(x) * 2 + spriteWidth(), 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(
      sheet,
      frame * CELL_W, anim.row * CELL_H, CELL_W, CELL_H,
      Math.round(x), Math.round(y), spriteWidth(), spriteHeight()
    );
    if (mirrored) ctx.restore();
    ctx.imageSmoothingEnabled = smoothing;
  }

  function drawStateMarks(x, y, m, phase) {
    if (state === 'sleep') {
      ctx.save();
      ctx.textBaseline = 'middle';
      ctx.lineJoin = 'round';
      ctx.strokeStyle = HALO;
      ctx.fillStyle = OUTLINE;
      for (let i = 0; i < 3; i += 1) {
        const progress = reducedMotion ? i / 3 : (phase * 0.42 + i / 3) % 1;
        const fade = Math.sin(progress * Math.PI);
        const size = Math.round(9 + progress * 6);
        // Nunca del todo transparente: con 0.15 el arranque del ciclo no se veía.
        ctx.globalAlpha = 0.45 + fade * 0.55;
        ctx.font = '700 ' + size + 'px ui-monospace, Menlo, monospace';
        const zx = x + spriteWidth() * 0.72 + progress * m * 3;
        const zy = y - m - progress * m * 7;
        // Contorno primero: así la zeta se lee sobre cualquier fondo, dentro o
        // fuera del terminal.
        ctx.lineWidth = Math.max(2, size * 0.28);
        ctx.strokeText('z', zx, zy);
        ctx.fillText('z', zx, zy);
      }
      ctx.restore();
    }
  }

  function drawPet(now) {
    const m = motionUnit();
    const elapsed = Math.max(0, now - stateStarted);
    const phase = elapsed / 1000;
    let hop = 0;

    // Caminar y saltar ya están dibujados cuadro a cuadro; agregarles rebote los
    // haría ver flotando. El resto recibe un vaivén suave.
    if (!reducedMotion && !isTravelling() && (state === 'idle' || state === 'look')) {
      hop = Math.sin(phase * 2.5) * m * 0.18;
    }

    const x = petX;
    const y = floorY() - spriteHeight() - hop;

    ctx.globalAlpha = state === 'sleep' ? 0.85 : 1;
    drawSprite(x, y, currentAnim(), elapsed, now);
    drawStateMarks(x, y, m, phase);

    ctx.globalAlpha = 1;
    drawBubble(x, y, now);

    // Área a borrar en el próximo cuadro, derivada de lo que se dibuja y no
    // estimada a ojo: las zetas suben `m * 8` sobre el pet más el cuerpo de la
    // letra, y el globo es más ancho que el sprite con textos largos.
    const zTop = m * 8 + 24;          // recorrido de las zetas + fuente y trazo
    const top = Math.min(y - zTop, y - 56);
    const span = Math.max(spriteWidth() * 2.2, 280);
    dirty = {
      x: Math.floor(x + spriteWidth() / 2 - span / 2),
      y: Math.floor(top),
      w: Math.ceil(span),
      h: Math.ceil(floorY() + 6 - top),
    };
  }

  function frame(now) {
    window.requestAnimationFrame(frame);
    const activeFrameMs = 1000 / 24;
    const frameMs = state === 'sleep' ? 125 : activeFrameMs;
    if (now - lastFrame < frameMs) return;
    // Acotado: al volver de una suspensión el salto sería de varios segundos y
    // teletransportaría al pet.
    const dt = Math.min(120, now - lastFrame);
    lastFrame = now;
    if (dirty) {
      ctx.clearRect(dirty.x, dirty.y, dirty.w, dirty.h);
    } else {
      ctx.clearRect(0, 0, width, height);
    }
    if (!ROAM_WINDOW && !hasTerminalRect && now - startedAt < RECT_GRACE) return;
    update(now, dt);
    drawPet(now);
  }

  window.addEventListener('resize', resize);
  resize();
  window.requestAnimationFrame(frame);
})();
</script>
</body>
</html>]]
end

local function executable_of(command)
    local text = (command or ""):lower()
    local executable = text:match("^%s*([^%s]+)") or ""
    return executable:match("([^/]+)$") or executable
end

local function classify_command(command)
    local text = (command or ""):lower()
    local executable = executable_of(command)

    if executable == "git" or executable == "gh" then return "git" end
    if executable == "swift" and text:match("%f[%a]test%f[%A]") then return "test" end
    if executable == "pytest" or executable == "rspec" or executable == "jest" then return "test" end
    if text:match("%f[%a]test%f[%A]") or text:match("%f[%a]spec%f[%A]") then return "test" end
    if text:match("%f[%a]build%f[%A]") or executable == "make" then return "build" end
    if text:match("%f[%a]deploy%f[%A]") or text:match("%f[%a]release%f[%A]") then return "deploy" end
    return "command"
end

-- El texto sale de VOICE, que son constantes del plugin; aun así se serializa
-- con %q para que un apóstrofe no rompa el JS.
local function say(line)
    if type(line) ~= "string" or line == "" then return end
    terminalis.background.eval(string.format("window.terminalPet.say(%q)", line))
end

local function react(kind)
    local allowed = {
        walk = true, hello = true,
    }
    if not allowed[kind] then return end
    terminalis.background.eval(string.format("window.terminalPet.react('%s')", kind))
end

local function look_at(cursor_x)
    local x = tonumber(cursor_x)
    if not x then return end
    terminalis.background.eval(string.format("window.terminalPet.look(%.1f)", x))
end

local function start_task(kind)
    local allowed = {
        command = true, git = true, test = true, build = true, deploy = true,
    }
    if not allowed[kind] then return end
    terminalis.background.eval(string.format("window.terminalPet.start('%s')", kind))
end

local function success_streak()
    return clamp(tonumber(terminalis.storage.get("success_streak")) or 0, 0, 99)
end

-- Único lugar que mueve la racha. Antes cada camino la tocaba por su cuenta:
-- dos la incrementaban y tres la leían sin actualizarla.
local function bump_streak(ok)
    local streak = ok and math.min(99, success_streak() + 1) or 0
    terminalis.storage.set("success_streak", streak)
    if not ok then mem.streak_said = nil end
    return streak
end

local function finish_task(result, duration_ms, streak)
    if result ~= "success" and result ~= "failure" then return end
    local duration = clamp(tonumber(duration_ms) or 0, 0, 86400000)
    local safe_streak = clamp(tonumber(streak) or 0, 0, 99)
    terminalis.background.eval(string.format(
        "window.terminalPet.finish('%s',%.0f,%.0f)",
        result, duration, safe_streak
    ))
end

function M.background_content()
    return ui.webview(html())
end

-- Puente para agentes de programación. Un agente que expone hooks (Claude Code,
-- Codex) puede avisarle al pet qué está haciendo abriendo
-- `terminalis://callback/terminal-pet?event=<evento>`, sin que el plugin
-- necesite leer la salida del terminal.
--
-- Es la única señal fiable de que el agente terminó: `on_command` no se dispara
-- adentro de una sesión y la heurística del Enter no sabe cuándo te respondieron.
local AGENT_EVENTS = {
    prompt = function() start_task("command") end,
    tool   = function() start_task("command") end,
    done   = function() finish_task("success", 0, bump_streak(true)) end,
    failed = function() finish_task("failure", 0, bump_streak(false)) end,
    notify = function() react("hello") end,
}

function M.on_load()
    terminalis.background.show()
    terminalis.on_url_callback(function(params)
        local handler = AGENT_EVENTS[(params or {}).event or ""]
        if handler then handler() end
    end)
end

function M.on_unload()
    terminalis.background.hide()
end

function M.on_keypress(ctx)
    local key = ctx.command or ""
    if #key ~= 1 or string.byte(key, 1) < 32 then return end
    say(touch())
    look_at(ctx.cursor_x)
end

function M.on_command(ctx)
    -- Entrar a una sesión interactiva no es ponerse a trabajar diez minutos: el
    -- proceso queda en primer plano esperándote. Se avisa igual, pero como un
    -- pulso que caduca solo, para que el pet no quede con los puntitos puestos
    -- toda la sesión.
    say(touch())

    if INTERACTIVE[executable_of(ctx.command)] then
        terminalis.background.eval("window.terminalPet.activity()")
        say(pick("welcome"))
        return
    end

    local kind = classify_command(ctx.command)
    -- Se guarda acá porque en `on_command_finish` sólo llega `ctx.process`, que
    -- es el basename: "npm test" se convierte en "npm" y la categoría se pierde.
    mem.running_kind = kind
    start_task(kind)
    say(line_for_start(kind))
end

function M.on_command_finish(ctx)
    local exit_code = tonumber(ctx.exit_code)
    if not exit_code then return end
    -- Salir de una sesión interactiva no es un resultado: cerrar con Ctrl+C da
    -- exit code distinto de cero y el pet se caía de espaldas sin motivo. Pero
    -- sí es una despedida, y después de un rato largo juntos merece otra frase.
    -- Lowercase igual que `executable_of` en `on_command`: si no, entrar como
    -- "Python" registraba la sesión y salir de ella no la reconocía.
    if INTERACTIVE[(ctx.process or ""):lower()] then
        react("hello")
        local minutes = (tonumber(ctx.duration_ms) or 0) / 60000
        say(minutes >= 10 and pick("farewellLong") or pick("farewell"))
        mem.greeted = false
        return
    end
    mem.last_result = os.time()
    local streak = bump_streak(exit_code == 0)
    finish_task(exit_code == 0 and "success" or "failure", ctx.duration_ms, streak)
    local kind = mem.running_kind or classify_command(ctx.process)
    mem.running_kind = nil
    say(line_for_finish(exit_code == 0, kind, tonumber(ctx.duration_ms) or 0, streak))
end

-- Estado del agente de programación, vía OSC 6974. Es la señal que faltaba:
-- adentro de una sesión no hay comandos que observar, y esto llega sin que el
-- plugin tenga que leer la salida del terminal.
function M.on_agent_state(ctx)
    local state = ctx.command or ""
    if state == "running" or state == "thinking" then
        start_task("command")
    elseif state == "waiting" then
        -- El agente terminó y te devolvió el control.
        mem.last_result = os.time()
        mem.busy_since = nil
        mem.pending_work = 0
        finish_task("success", 0, bump_streak(true))
    end
end

-- El terminal escribió algo. No llega el texto, sólo el hecho: alcanza para
-- saber si hay trabajo en curso y no pide permisos.
--
-- Es la única señal que no depende de que nadie coopere: vale igual para un
-- agente, un build largo o un `docker pull`. A cambio no distingue quién
-- escribe ni si salió bien, así que el estado del agente y el exit code del
-- shell mandan sobre ésta cuando están disponibles.
-- Un tramo largo de salida que se corta es "algo terminó". Es la única forma de
-- saberlo que no depende de que el agente coopere: sirve igual para Codex, para
-- un agente que no exista todavía o para un `npm install`.
local WORK_BURST = 5    -- segundos de salida continua para que cuente como trabajo
local WORK_QUIET = 8    -- silencio que confirma que de verdad terminó

function M.on_terminal_activity(ctx)
    local now = os.time()
    if ctx.command == "busy" then
        mem.last_activity = now
        -- Si el tab se cerró en plena salida, su "idle" nunca llega y el inicio
        -- de esa ráfaga quedaría colgado, inflando la próxima. Un hueco largo
        -- entre avisos significa ráfaga nueva.
        if now - mem.busy_last > 3 then mem.busy_since = now end
        mem.busy_last = now
        mem.busy_since = mem.busy_since or now
        terminalis.background.eval("window.terminalPet.activity()")
        return
    end

    -- Se cortó la salida, pero todavía no se sabe si terminó: un agente escribe
    -- a los tirones —piensa, busca, responde— y cada pausa no es una tarea
    -- distinta. Sólo se anota el trabajo; cerrarlo es cosa de `on_tick`.
    local worked = mem.busy_since and (now - mem.busy_since) or 0
    mem.busy_since = nil
    if worked >= WORK_BURST then mem.pending_work = worked end
end

-- Cierra el trabajo pendiente recién cuando el silencio se sostiene. Sin esto,
-- una sola consulta a un agente contaba como cinco tareas terminadas.
local function close_pending_work()
    if mem.pending_work == 0 then return nil end
    local now = os.time()
    if (now - mem.busy_last) < WORK_QUIET then return nil end
    local worked = mem.pending_work
    mem.pending_work = 0
    -- Si el shell o el agente ya informaron un resultado real, ese manda.
    if (now - mem.last_result) < WORK_QUIET then return nil end

    -- La racha no se toca: es un contador de éxitos reales y llenarlo de
    -- suposiciones la haría mentir.
    finish_task("success", worked * 1000, success_streak())
    if worked >= 30 then return pick("slow") end
    return math.random() < 0.4 and pick("normal") or nil
end

-- Un agente puede dejar su estado en el storage del plugin desde afuera:
--     defaults write com.dmernes.terminaltabs \
--       "terminalis.plugin.terminal-pet.storage.agent_state" -string running
--
-- Es la única vía que no necesita nada del lado de la app. A cambio, la lectura
-- va contra `on_tick`, así que el pet se entera con hasta tres segundos de
-- retraso. Ver agent-hooks.md.
local last_agent_state = nil

-- Inactividad en dos escalones. `on_tick` corre cada 3s mientras el pet está
-- visible, que es la única forma de notar el paso del tiempo sin que pase nada:
-- los demás hooks sólo se disparan cuando hacés algo.
local function check_idle()
    local quiet = os.time() - mem.last_activity
    local sleeps_at = sleep_seconds()

    if quiet >= sleeps_at then
        mem.was_asleep = true
        return nil
    end
    -- Un solo comentario por escalón: si hablara en cada tick sería insoportable.
    if quiet >= math.floor(sleeps_at * 0.66) and mem.idle_stage < 2 then
        mem.idle_stage = 2
        return pick("longIdle")
    end
    if quiet >= math.floor(sleeps_at * 0.33) and mem.idle_stage < 1 then
        mem.idle_stage = 1
        return pick("bored")
    end
    return nil
end

function M.on_tick()
    say(close_pending_work())
    say(check_idle())

    local current = terminalis.storage.get("agent_state")
    if type(current) ~= "string" or current == last_agent_state then return end
    last_agent_state = current
    if current == "running" or current == "thinking" then
        start_task("command")
    elseif current == "error" then
        finish_task("failure", 0, bump_streak(false))
    elseif current == "waiting" then
        finish_task("success", 0, bump_streak(true))
    end
end

function M.on_cwd_change()
    react("walk")
end

function M.on_tab_open()
    react("hello")
    say(line_for_greeting())
end

function M.settings_content()
    return {
        ui.picker("Personaje", {
            options = PET_ORDER,
            value = pet_name(),
            on_change = "set_pet",
        }),
        ui.slider("Posición", {
            value = home_position(), min = 0.0, max = 1.0, step = 0.05,
            detail = "izquierda ← → derecha", on_change = "set_position",
        }),
        ui.separator(),
        ui.slider("Tamaño", {
            value = pet_size(), min = 0.7, max = 1.6, step = 0.1,
            on_change = "set_size",
        }),
        ui.slider("Se duerme después de", {
            value = sleep_seconds(), min = 10, max = 120, step = 5,
            detail = "segundos", on_change = "set_sleep_seconds",
        }),
        ui.toggle("Pasear por toda la ventana", {
            value = roam_whole_window(), icon = "arrow.left.and.right",
            on_change = "set_roam",
        }),
        ui.toggle("Globitos de reacción", {
            value = bubbles_enabled(), icon = "text.bubble",
            on_change = "set_bubbles",
        }),
    }
end

function M.set_pet(ctx)
    if not PETS[ctx.value] then return end
    terminalis.storage.set("pet", ctx.value)
    terminalis.background.reload()
end

function M.set_position(ctx)
    terminalis.storage.set("home_x", clamp(tonumber(ctx.value) or 0.05, 0.0, 1.0))
    terminalis.background.reload()
end

function M.set_size(ctx)
    terminalis.storage.set("size", clamp(tonumber(ctx.value) or 1.4, 0.7, 1.6))
    terminalis.background.reload()
end

function M.set_sleep_seconds(ctx)
    terminalis.storage.set("sleep_seconds", clamp(tonumber(ctx.value) or 30, 10, 120))
    terminalis.background.reload()
end

function M.set_roam(ctx)
    terminalis.storage.set("roam_window", ctx.value == "true")
    terminalis.background.reload()
end

function M.set_bubbles(ctx)
    terminalis.storage.set("bubbles", ctx.value == "true")
    terminalis.background.reload()
end

return M
