local M = {}

M.name        = "space-invaders"
M.version     = "1.0"
M.author      = "terminalis-plugins"
M.description = "Play a sandboxed Space Invaders game inside Terminalis."
M.permissions = {}

M.panel = {
    title = "Space Invaders",
    icon = "gamecontroller.fill",
    width = 260,
    side = "right",
}

local game_html = [[
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  * { box-sizing: border-box; }
  html, body { width: 100%; height: 100%; margin: 0; overflow: hidden; background: #050807; }
  body { display: grid; place-items: center; color: #72ff72; font-family: Menlo, Monaco, monospace; }
  #wrap { width: min(96vw, 1200px); }
  #hud { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; }
  canvas { width: 100%; aspect-ratio: 8 / 5; display: block; border: 1px solid #245c2b; background: #020403; box-shadow: 0 0 30px #0b3d16; }
  #help { margin-top: 10px; text-align: center; color: #69a76f; font-size: 12px; }
</style>
</head>
<body>
<div id="wrap">
  <div id="hud"><span>SPACE INVADERS</span><span id="score">SCORE 0000</span></div>
  <canvas id="game" width="800" height="500" tabindex="0"></canvas>
  <div id="help">← → / A D: move &nbsp; SPACE: fire &nbsp; R: restart</div>
</div>
<script>
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const scoreNode = document.getElementById('score');
const W = canvas.width, H = canvas.height;
let ship, enemies, bullets, direction, score, state, last, shotAt;
const keys = new Set();
const glyphs = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&';

function reset() {
  ship = { x: W / 2, y: H - 42 };
  enemies = [];
  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < 11; col++) {
      enemies.push({
        x: 105 + col * 55,
        y: 65 + row * 42,
        char: glyphs[(row * 11 + col) % glyphs.length]
      });
    }
  }
  bullets = [];
  direction = 1;
  score = 0;
  state = 'playing';
  last = performance.now();
  shotAt = 0;
  scoreNode.textContent = 'SCORE 0000';
  canvas.focus();
}

function fire(now) {
  if (state === 'playing' && now - shotAt > 180) {
    bullets.push({ x: ship.x, y: ship.y - 18 });
    shotAt = now;
  }
}

function wasHit(enemy, bullet) {
  return Math.abs(enemy.x - bullet.x) < 15 && Math.abs(enemy.y - bullet.y) < 16;
}
console.assert(wasHit({ x: 10, y: 10 }, { x: 10, y: 10 }));
console.assert(!wasHit({ x: 10, y: 10 }, { x: 25, y: 10 }));

function update(dt, now) {
  if (state !== 'playing') return;
  const movement = (keys.has('ArrowLeft') || keys.has('a') ? -1 : 0)
    + (keys.has('ArrowRight') || keys.has('d') ? 1 : 0);
  ship.x = Math.max(24, Math.min(W - 24, ship.x + movement * 300 * dt));
  if (keys.has(' ')) fire(now);

  bullets.forEach(b => b.y -= 430 * dt);
  bullets = bullets.filter(b => b.y > -10);

  let edge = false;
  enemies.forEach(e => {
    e.x += direction * 45 * dt;
    if (e.x < 24 || e.x > W - 24) edge = true;
  });
  if (edge) {
    direction *= -1;
    enemies.forEach(e => { e.x = Math.max(24, Math.min(W - 24, e.x)); e.y += 18; });
  }

  for (let bi = bullets.length - 1; bi >= 0; bi--) {
    const b = bullets[bi];
    const hit = enemies.findIndex(e => wasHit(e, b));
    if (hit >= 0) {
      enemies.splice(hit, 1);
      bullets.splice(bi, 1);
      score += 10;
      scoreNode.textContent = 'SCORE ' + String(score).padStart(4, '0');
    }
  }

  if (!enemies.length) state = 'won';
  else if (enemies.some(e => e.y >= ship.y - 25)) state = 'lost';
}

function draw() {
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = '#17351b';
  for (let y = 20; y < H; y += 24) for (let x = 18; x < W; x += 28) ctx.fillRect(x, y, 1, 1);

  ctx.fillStyle = '#72ff72';
  ctx.font = 'bold 24px Menlo, monospace';
  ctx.textAlign = 'center';
  enemies.forEach(e => ctx.fillText(e.char, e.x, e.y));

  ctx.fillStyle = '#d6ffd6';
  bullets.forEach(b => ctx.fillRect(b.x - 2, b.y - 8, 4, 12));
  ctx.font = 'bold 28px Menlo, monospace';
  ctx.fillText('/^\\', ship.x, ship.y);

  if (state !== 'playing') {
    ctx.fillStyle = 'rgba(2,4,3,.82)';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = state === 'won' ? '#72ff72' : '#ff6969';
    ctx.font = 'bold 38px Menlo, monospace';
    ctx.fillText(state === 'won' ? 'YOU WIN' : 'GAME OVER', W / 2, H / 2 - 10);
    ctx.fillStyle = '#b7d9ba';
    ctx.font = '16px Menlo, monospace';
    ctx.fillText('Press R to restart', W / 2, H / 2 + 30);
  }
}

function loop(now) {
  const dt = Math.min((now - last) / 1000, .04);
  last = now;
  update(dt, now);
  draw();
  requestAnimationFrame(loop);
}

addEventListener('keydown', e => {
  const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  if (['ArrowLeft', 'ArrowRight', ' ', 'a', 'd'].includes(key)) e.preventDefault();
  keys.add(key);
  if (key === ' ') fire(performance.now());
  if (key === 'r') reset();
});
addEventListener('keyup', e => keys.delete(e.key.length === 1 ? e.key.toLowerCase() : e.key));
addEventListener('blur', () => keys.clear());
canvas.addEventListener('click', () => canvas.focus());

reset();
requestAnimationFrame(loop);
</script>
</body>
</html>
]]

function M.panel_content()
    return {
        ui.label("Juego aislado: no ejecuta comandos ni modifica la terminal.", { color = "#69A76F" }),
        ui.separator(),
        ui.button("Jugar", { action = "play", icon = "play.fill", style = "primary" }),
        ui.label("Mover: ← → / A D", { color = "#888888" }),
        ui.label("Disparar: espacio", { color = "#888888" }),
    }
end

function M.play()
    terminalis.tab.open(game_html, { title = "Space Invaders", icon = "gamecontroller.fill" })
end

return M
