-- Shell plumbing shared by the scanner and the session operations.
--
-- terminalis.shell runs commands through whatever shell the user configured,
-- which may be fish — where heredocs don't exist and `$?` isn't the exit
-- status. Everything here is therefore re-wrapped in `/bin/sh -c '...'` so the
-- scripts get POSIX semantics no matter what the user's shell is.

local M = {}

-- Single-quote for /bin/sh: close the quote, escape the literal quote, reopen.
-- The same idiom is understood by sh, bash, zsh and fish, so it is safe as the
-- outer quoting too.
function M.quote(value)
    return "'" .. tostring(value or ""):gsub("'", "'\\''") .. "'"
end

-- Session ids are the only untrusted value that ever reaches a command line.
-- Both agents identify sessions by UUID, so ids are allowlisted rather than
-- escaped: anything else cannot be a real session, and refusing it removes
-- command injection, argument injection and path traversal in one check.
local UUID = "^%x%x%x%x%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%x%x%x%x%x%x%x%x$"

function M.is_session_id(id)
    return type(id) == "string" and id:match(UUID) ~= nil
end

function M.posix(script)
    return "/bin/sh -c " .. M.quote(script)
end

-- Plain stdout, no exit status. Returns nil, err when the shell permission is
-- missing or the command times out.
function M.capture(script, timeout)
    return terminalis.shell(M.posix(script), { timeout = timeout or 20 })
end

local MARKER = "__TT_EXIT:"

-- terminalis.shell hands back stdout only, so the exit status rides out on a
-- trailing marker and stderr is folded into stdout — without it a failure
-- would surface as a bare exit code with no reason attached.
function M.run(script, timeout)
    local wrapped = table.concat({
        "__tt_out=$( { " .. script,
        "} 2>&1 )",
        "__tt_rc=$?",
        'printf %s "$__tt_out"',
        "printf '" .. MARKER .. "%d' \"$__tt_rc\"",
    }, "\n")

    local raw, err = terminalis.shell(M.posix(wrapped), { timeout = timeout or 20 })
    if err then return false, err end

    raw = raw or ""
    local code = raw:match(MARKER .. "(%d+)%s*$")
    local output = raw:gsub(MARKER .. "%d+%s*$", ""):gsub("%s+$", "")
    if tonumber(code) == 0 then
        return true, output
    end
    if output == "" then
        output = code and ("el comando falló (código " .. code .. ")")
                       or "el comando no devolvió estado"
    end
    return false, output
end

return M
