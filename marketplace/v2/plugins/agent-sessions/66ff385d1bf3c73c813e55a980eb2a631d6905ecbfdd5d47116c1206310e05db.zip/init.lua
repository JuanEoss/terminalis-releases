-- agent-sessions — browse, rename, resume and delete Claude Code and Codex
-- sessions from a Terminalis side panel.

local scan = require("scan")
local ops  = require("ops")

local M = {}

M.name        = "agent-sessions"
M.version     = "1.2.0"
M.author      = "dmernes"
M.description = "Navegador de sesiones de Claude Code y Codex: una card por sesión, con renombrar, reanudar y eliminar."
M.permissions = { "shell" }

M.panel = {
    title     = "Sesiones",
    icon      = "clock.arrow.circlepath",
    width     = 340,
    min_width = 260,
    side      = "right",
    header_buttons = {
        { icon = "arrow.clockwise", action = "refresh", tooltip = "Volver a escanear" },
    },
}

-- Same formatting for every card: the agent is told apart by its logo and by
-- the word on the chip, not by tinting each card a different colour.
--
-- `brand:<key>` draws the real brand mark from the app's own icon table — the
-- same vectors the sidebar uses for terminal tabs — instead of approximating
-- each agent with an SF Symbol. Codex maps to the OpenAI logo, exactly like
-- brandKey(for:) does for terminal tabs.
local AGENTS = {
    claude = { label = "Claude", icon = "brand:claude" },
    codex  = { label = "Codex",  icon = "brand:openai" },
}

local PAGE_SIZE = 12
local GREY      = "#8E8E93"
local RED       = "#FF453A"
local GREEN     = "#30D158"
local PURPLE    = "#BF5AF2"

-- Every button inside a card needs its own handler on M: ui.button dispatches
-- by function name and carries no payload, so the card index is baked into the
-- name and resolved against state.cards at render time. That makes the number
-- of cards a hard ceiling, and the panel has to say so rather than leave a
-- «Mostrar más» that does nothing.
local MAX_CARDS = 240
local MAX_TITLE_LENGTH = 140

-- view: "list" | "detail"
-- mode: nil | "rename" | "delete"   (sub-state of the detail view)
local state = {
    view    = "list",
    mode    = nil,
    error   = nil,
    notice  = nil,
    query   = "",
    visible = PAGE_SIZE,

    sessions = nil,   -- nil = not scanned yet; flat, newest first
    selected = nil,
    cards    = {},    -- card index -> session

    aliases  = nil,   -- nil = not read yet
    prefs    = nil,
}

--------------------------------------------------------------------------------
-- preferences and aliases
--------------------------------------------------------------------------------

local function prefs()
    if state.prefs == nil then
        local stored = terminalis.storage.get("prefs") or {}
        state.prefs = {
            -- Codex opens a rollout for every automation run, so most of them
            -- have neither a name nor a prompt. Hidden by default or the list
            -- is mostly noise.
            hide_empty  = stored.hide_empty ~= false,
            sync_claude = stored.sync_claude ~= false,
        }
    end
    return state.prefs
end

local function save_prefs()
    terminalis.storage.set("prefs", state.prefs)
end

local function aliases()
    if state.aliases == nil then
        state.aliases = terminalis.storage.get("aliases") or {}
    end
    return state.aliases
end

--------------------------------------------------------------------------------
-- formatting helpers
--------------------------------------------------------------------------------

local function agent_of(session)
    return AGENTS[session.agent] or AGENTS.claude
end

-- A session with no name and no user prompt never got a first turn.
local function is_empty(session)
    return session.title == "" and session.auto_title == "" and not session.named
end

local function display_title(session)
    local alias = aliases()[session.id]
    if alias and alias ~= "" then return alias end
    if session.title ~= "" then return session.title end
    if session.auto_title ~= "" then return session.auto_title end
    return "(sin título)"
end

local function rel_time(timestamp)
    timestamp = tonumber(timestamp) or 0
    if timestamp <= 0 then return "sin fecha" end
    local diff = os.time() - math.floor(timestamp)
    if diff < 0 then diff = 0 end
    if diff < 60 then return "ahora" end
    if diff < 3600 then return string.format("hace %dm", diff // 60) end
    if diff < 86400 then return string.format("hace %dh", diff // 3600) end
    if diff < 604800 then return string.format("hace %dd", diff // 86400) end
    return os.date("%d/%m/%y", math.floor(timestamp))
end

-- Card text competes for a ~340pt panel, so it gets clipped rather than
-- squeezed. The cut is counted in characters, not bytes: slicing an accented
-- title mid-sequence would hand SwiftUI broken UTF-8.
local function trim(text, width)
    local length = utf8.len(text)
    if not length then return text:sub(1, width) end
    if length <= width then return text end
    local cut = utf8.offset(text, width) or (width + 1)
    return (text:sub(1, cut - 1):gsub("%s+$", "")) .. "…"
end

local function matches(query, ...)
    if query == "" then return true end
    for _, field in ipairs({ ... }) do
        if field and field ~= "" and field:lower():find(query, 1, true) then
            return true
        end
    end
    return false
end

local function html_escape(text)
    return (tostring(text or "")
        :gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"):gsub('"', "&quot;"))
end

--------------------------------------------------------------------------------
-- data
--------------------------------------------------------------------------------

local function reload_data()
    local sessions, err = scan.load()
    state.sessions = sessions or {}
    state.error = err
end

local function listed()
    local out, hide_empty = {}, prefs().hide_empty
    for _, session in ipairs(state.sessions or {}) do
        if not (hide_empty and is_empty(session))
            and matches(state.query, display_title(session), session.project,
                        session.branch, session.cwd, session.id) then
            out[#out + 1] = session
        end
    end
    return out
end

local function redraw()
    terminalis.panel.reload()
end

-- Called after a session is deleted: the panel drops back to the list instead
-- of pointing at a file that no longer exists.
local function forget_selected()
    state.selected, state.mode, state.view = nil, nil, "list"
    reload_data()
end

--------------------------------------------------------------------------------
-- navigation
--------------------------------------------------------------------------------

function M.on_load()
    terminalis.log("agent-sessions cargado")
end

function M.refresh()
    state.sessions, state.selected, state.mode, state.notice = nil, nil, nil, nil
    state.view, state.visible = "list", PAGE_SIZE
    redraw()
end

function M.back_to_list()
    state.view, state.selected, state.mode, state.notice = "list", nil, nil, nil
    redraw()
end

function M.on_search(ctx)
    state.query = (ctx.value or ""):lower()
    state.visible = PAGE_SIZE
    redraw()
end

function M.clear_search()
    state.query, state.visible = "", PAGE_SIZE
    redraw()
end

-- Doubling instead of adding a page: 165 sessions are four taps away rather
-- than fourteen, and the first screen stays short.
function M.show_more()
    state.visible = math.min(state.visible * 2, MAX_CARDS)
    redraw()
end

local function select_card(index)
    local session = state.cards[index]
    if not session then return false end
    state.selected = session
    return true
end

local function open_card(index, mode)
    if not select_card(index) then return end
    state.view, state.mode, state.notice = "detail", mode, nil
    redraw()
end

--------------------------------------------------------------------------------
-- session actions
--------------------------------------------------------------------------------

-- ops.resume_command returns nil for a session whose id is not a UUID. That
-- command would be typed into the user's live shell, so it is never built from
-- an id the scanner could not vouch for.
local function resume_command()
    local session = state.selected
    if not session then return nil end
    local command = ops.resume_command(session)
    if not command then
        terminalis.notify("El id de esta sesión no es un UUID: no se ejecuta ningún comando",
                          { level = "error" })
    end
    return command, session
end

function M.resume_new_tab()
    local command, session = resume_command()
    if not command then return end
    if session.cwd ~= "" and session.cwd:sub(1, 1) == "/" then
        terminalis.tab.new({ cwd = session.cwd, name = trim(display_title(session), 24) })
    else
        terminalis.tab.new()
    end
    terminalis.send(command .. "\n")
end

function M.resume_here()
    local command = resume_command()
    if not command then return end
    terminalis.send(command .. "\n")
end

function M.copy_command()
    local command = resume_command()
    if not command then return end
    terminalis.clipboard(command)
    terminalis.notify("Comando copiado")
end

function M.copy_id()
    if not state.selected then return end
    terminalis.clipboard(state.selected.id)
    terminalis.notify("ID copiado")
end

function M.copy_path()
    if not state.selected then return end
    terminalis.clipboard(state.selected.file)
    terminalis.notify("Ruta del transcript copiada")
end

-- Resume is the one card action that does not navigate: you stay on the list
-- and the session opens in a new terminal tab.
for index = 1, MAX_CARDS do
    M["card_open_"   .. index] = function() open_card(index, nil) end
    M["card_rename_" .. index] = function() open_card(index, "rename") end
    M["card_delete_" .. index] = function() open_card(index, "delete") end
    M["card_resume_" .. index] = function()
        if select_card(index) then M.resume_new_tab() end
    end
end

function M.start_rename()
    state.mode, state.notice = "rename", nil
    redraw()
end

function M.cancel_mode()
    state.mode, state.notice = nil, nil
    redraw()
end

-- The alias always wins in this panel. On Claude the name is additionally
-- written into the transcript so `claude --resume` shows it too; Codex keeps
-- its thread name in an index its CLI rewrites, so there it stays local.
function M.do_rename(ctx)
    local session = state.selected
    if not session then return end

    local name = (ctx.value or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" then
        M.clear_alias()
        return
    end
    if (utf8.len(name) or 0) > MAX_TITLE_LENGTH then
        name = trim(name, MAX_TITLE_LENGTH)
    end

    aliases()[session.id] = name
    terminalis.storage.set("aliases", state.aliases)

    if session.agent == "claude" and prefs().sync_claude then
        local ok, err = ops.apply_claude_title(session, name)
        if ok then
            session.title, session.named = name, true
            state.notice = { text = "Renombrada, también en Claude", color = GREEN }
        else
            state.notice = { text = "Alias guardado; en Claude no: " .. trim(err, 120), color = RED }
        end
    else
        state.notice = { text = "Alias guardado en el plugin", color = GREEN }
    end

    state.mode = nil
    redraw()
end

function M.clear_alias()
    local session = state.selected
    if not session then return end

    aliases()[session.id] = nil
    terminalis.storage.set("aliases", state.aliases)

    -- Undo the transcript write too, by restoring whatever title Claude had
    -- generated on its own before the rename.
    if session.agent == "claude" and prefs().sync_claude
        and session.named and session.auto_title ~= "" then
        local ok = ops.apply_claude_title(session, session.auto_title)
        if ok then
            session.title, session.named = session.auto_title, false
        end
    end

    state.mode = nil
    state.notice = { text = "Alias eliminado", color = GREY }
    redraw()
end

function M.ask_delete()
    state.mode, state.notice = "delete", nil
    redraw()
end

function M.do_delete()
    local session = state.selected
    if not session then return end

    local ok, output = ops.delete(session)
    if not ok then
        state.mode = nil
        state.notice = { text = "No se pudo eliminar: " .. output, color = RED }
        redraw()
        return
    end

    aliases()[session.id] = nil
    terminalis.storage.set("aliases", state.aliases)

    -- `codex delete` can fail while the file removal still succeeds, which
    -- leaves a stale entry in the Codex index worth telling the user about.
    if output ~= "" then
        terminalis.notify(trim(output, 160), { level = "warning" })
    else
        terminalis.notify("Sesión eliminada", { level = "warning" })
    end

    forget_selected()
    redraw()
end

function M.open_detail_tab()
    local session = state.selected
    if not session then return end

    local theme  = terminalis.theme()
    local accent = theme.accent or "#0A84FF"
    local bg     = theme.is_dark and "#1C1C1E" or "#FFFFFF"
    local fg     = theme.is_dark and "#E5E5EA" or "#1C1C1E"
    local card   = theme.is_dark and "#2C2C2E" or "#F2F2F7"

    local function row(key, value)
        return "<div class=\"row\"><div class=\"k\">" .. html_escape(key) .. "</div>"
            .. html_escape(value) .. "</div>"
    end

    local html = table.concat({
        "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><style>",
        "body{font:14px -apple-system,sans-serif;padding:32px;background:", bg, ";color:", fg, "}",
        "h1{font-size:20px;margin:0 0 16px;color:", accent, "}",
        ".row{margin:10px 0;padding:12px;background:", card,
        ";border-radius:8px;word-break:break-all;border-left:3px solid ", accent, "}",
        ".k{color:", GREY, ";font-size:11px;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}",
        ".badge{display:inline-block;padding:3px 10px;border-radius:12px;font-size:12px;font-weight:600;",
        "background:", accent, ";color:#fff;margin-right:6px}",
        "code{font-family:Menlo,monospace}",
        "</style></head><body>",
        "<h1>", html_escape(display_title(session)), "</h1>",
        "<span class=\"badge\">", agent_of(session).label, "</span>",
        "<span class=\"badge\">", tostring(session.count), " mensajes</span>",
        session.branch ~= "" and ("<span class=\"badge\">" .. html_escape(session.branch) .. "</span>") or "",
        row("Proyecto", scan.pretty_path(session.cwd)),
        row("Session ID", session.id),
        row("Última actividad", rel_time(session.mtime)),
        row("Transcript", scan.pretty_path(session.file)),
        "<div class=\"row\"><div class=\"k\">Reanudar</div><code>",
        html_escape(ops.resume_command(session) or "id no válido — sesión no reanudable"),
        "</code></div>",
        "</body></html>",
    })

    terminalis.tab.open(html, { title = trim(display_title(session), 28), icon = agent_of(session).icon })
end

local ACTIONS = {
    ["Reanudar en pestaña nueva"]   = M.resume_new_tab,
    ["Reanudar acá"]                = M.resume_here,
    ["Copiar comando"]              = M.copy_command,
    ["Copiar session ID"]           = M.copy_id,
    ["Copiar ruta del transcript"]  = M.copy_path,
    ["Renombrar"]                   = M.start_rename,
    ["Ver detalle completo"]        = M.open_detail_tab,
}

function M.session_action(ctx)
    local handler = ACTIONS[ctx.label or ""]
    if handler then handler() end
end

--------------------------------------------------------------------------------
-- settings modal
--------------------------------------------------------------------------------

function M.settings_content()
    local alias_count = 0
    for _ in pairs(aliases()) do alias_count = alias_count + 1 end

    return {
        ui.toggle("Ocultar sesiones sin actividad", {
            value = prefs().hide_empty, icon = "eye.slash",
            detail = "sin nombre ni prompt", on_change = "set_hide_empty",
        }),
        ui.toggle("Renombrar también en Claude", {
            value = prefs().sync_claude, icon = "pencil",
            detail = "escribe en el transcript", on_change = "set_sync_claude",
        }),
        ui.label("Codex guarda el nombre en un índice que reescribe su CLI, así que ahí el alias es sólo del plugin.",
                 { color = GREY }),
        ui.separator(),
        ui.button("Borrar los " .. alias_count .. " alias guardados", {
            action = "wipe_aliases", icon = "trash", style = "destructive",
            disabled = alias_count == 0,
        }),
    }
end

function M.set_hide_empty(ctx)
    prefs().hide_empty = ctx.value == "true"
    save_prefs()
    state.visible = PAGE_SIZE
    redraw()
end

function M.set_sync_claude(ctx)
    prefs().sync_claude = ctx.value == "true"
    save_prefs()
end

function M.wipe_aliases()
    state.aliases = {}
    terminalis.storage.set("aliases", state.aliases)
    terminalis.notify("Alias borrados")
    redraw()
end

--------------------------------------------------------------------------------
-- panel views
--------------------------------------------------------------------------------

-- One session card. ui.group with neither title nor icon renders just the
-- rounded container, so the card can lead with a real title — bold, in the
-- agent's brand colour, with its symbol — instead of the 11pt grey header the
-- group would impose. ui.list was the alternative and its row icon is always
-- secondary grey, which is exactly what made the two agents indistinguishable.
local function push_card(parts, session)
    if #state.cards >= MAX_CARDS then return end
    state.cards[#state.cards + 1] = session

    local index = #state.cards
    local agent = agent_of(session)

    local meta = { agent.label, rel_time(session.mtime) }
    if session.count > 0 then
        meta[#meta + 1] = session.count .. (session.count == 1 and " msg" or " msgs")
    end
    if session.branch ~= "" then meta[#meta + 1] = session.branch end
    if aliases()[session.id] then meta[#meta + 1] = "alias" end

    parts[#parts + 1] = ui.group({
        ui.label(trim(display_title(session), 70), { bold = true, icon = agent.icon }),
        ui.badge(trim(table.concat(meta, " · "), 52)),
        ui.label(trim(scan.pretty_path(session.cwd), 46), { icon = "folder", color = GREY }),
        -- Botones sin texto: la app los dibuja cuadrados y el ui.spacer empuja
        -- el chevron al borde derecho de la card.
        ui.row(
            ui.button("", { action = "card_resume_" .. index, icon = "play.fill",
                            disabled = not session.safe_id }),
            ui.button("", { action = "card_rename_" .. index, icon = "pencil" }),
            ui.button("", { action = "card_delete_" .. index, icon = "trash" }),
            ui.spacer(),
            ui.button("", { action = "card_open_" .. index, icon = "chevron.right" })
        ),
    })
end

local function error_view()
    return {
        ui.label("No se pudieron leer las sesiones", { color = RED, bold = true,
                                                       icon = "exclamationmark.triangle.fill" }),
        ui.label(state.error, { color = GREY }),
        ui.label("Otorgá el permiso «shell» en Ajustes → Plugins.", { color = GREY }),
        ui.spacer(),
        ui.button("Reintentar", { action = "refresh", icon = "arrow.clockwise" }),
    }
end

local function detail_view()
    local session = state.selected
    local agent   = agent_of(session)

    local parts = {
        ui.list({ { label = "Sesiones", icon = "chevron.left" } }, { on_select = "back_to_list" }),
        ui.label(display_title(session), { bold = true, icon = agent.icon }),
        ui.label(scan.pretty_path(session.cwd), { icon = "folder", color = GREY }),
        ui.row(
            ui.stat("Agente", agent.label, { icon = agent.icon }),
            ui.stat("Mensajes", tostring(session.count), { icon = "text.bubble" })
        ),
    }

    if session.branch ~= "" then
        parts[#parts + 1] = ui.badge(session.branch)
    end
    if aliases()[session.id] then
        parts[#parts + 1] = ui.badge("alias local")
    end
    if state.notice then
        parts[#parts + 1] = ui.label(state.notice.text, { color = state.notice.color })
    end
    parts[#parts + 1] = ui.separator()

    if state.mode == "rename" then
        parts[#parts + 1] = ui.input("Nuevo nombre…", { value = display_title(session), on_submit = "do_rename" })
        if session.agent == "claude" and prefs().sync_claude then
            parts[#parts + 1] = ui.label("Se escribe también en el transcript de Claude.", { color = GREY })
        else
            parts[#parts + 1] = ui.label("Sólo dentro de este panel.", { color = GREY })
        end
        parts[#parts + 1] = ui.row(
            ui.button("Cancelar", { action = "cancel_mode", icon = "xmark", style = "plain" }),
            ui.button("Quitar alias", { action = "clear_alias", icon = "arrow.uturn.backward",
                                        disabled = aliases()[session.id] == nil })
        )
        return parts
    end

    if state.mode == "delete" then
        parts[#parts + 1] = ui.label("Eliminar la sesión", { bold = true, color = RED,
                                                             icon = "exclamationmark.octagon.fill" })
        parts[#parts + 1] = ui.label(session.agent == "codex"
            and "Se ejecuta «codex delete», que también limpia el índice de Codex. No se puede deshacer."
            or "Se borra el .jsonl del disco. No se puede deshacer.", { color = GREY })
        parts[#parts + 1] = ui.row(
            ui.button("Cancelar", { action = "cancel_mode", style = "plain" }),
            ui.button("Eliminar", { action = "do_delete", icon = "trash", style = "destructive" })
        )
        return parts
    end

    -- Anything that ends up on a command line is hidden for a session whose id
    -- the scanner could not confirm to be a UUID.
    local rows = {
        { label = "Renombrar",                   icon = "pencil" },
        { label = "Copiar session ID",           icon = "number" },
        { label = "Copiar ruta del transcript",  icon = "doc.on.doc" },
        { label = "Ver detalle completo",        icon = "doc.text.magnifyingglass" },
    }
    if session.safe_id then
        table.insert(rows, 1, { label = "Reanudar en pestaña nueva", icon = "arrow.up.forward.app" })
        table.insert(rows, 2, { label = "Reanudar acá",              icon = "return" })
        table.insert(rows, 4, { label = "Copiar comando",            icon = "terminal" })
    else
        parts[#parts + 1] = ui.label("El id no es un UUID: reanudar y eliminar están deshabilitados.",
                                     { color = RED, icon = "exclamationmark.triangle.fill" })
    end

    parts[#parts + 1] = ui.list(rows, { on_select = "session_action" })
    parts[#parts + 1] = ui.spacer()
    parts[#parts + 1] = ui.button("Eliminar", { action = "ask_delete", icon = "trash",
                                                style = "destructive" })
    return parts
end

local function list_view()
    local claude, codex = 0, 0
    for _, session in ipairs(state.sessions or {}) do
        if not (prefs().hide_empty and is_empty(session)) then
            if session.agent == "claude" then claude = claude + 1 else codex = codex + 1 end
        end
    end

    local parts = {
        ui.row(
            ui.stat("Claude", tostring(claude), { icon = AGENTS.claude.icon }),
            ui.stat("Codex", tostring(codex), { icon = AGENTS.codex.icon })
        ),
        ui.input("Buscar sesión, proyecto o rama…", { value = state.query, on_submit = "on_search" }),
    }

    if state.query ~= "" then
        parts[#parts + 1] = ui.list(
            { { label = "Limpiar filtro", detail = '"' .. state.query .. '"', icon = "xmark.circle" } },
            { on_select = "clear_search" })
    end

    local matching = listed()
    if #matching == 0 then
        parts[#parts + 1] = ui.label(state.query ~= "" and "Sin resultados"
                                                        or "No se encontraron sesiones de Claude ni de Codex.",
                                     { color = GREY })
        return parts
    end

    local shown = math.min(state.visible, #matching, MAX_CARDS)
    for index = 1, shown do push_card(parts, matching[index]) end

    local rest = #matching - shown
    if rest > 0 then
        if shown >= MAX_CARDS then
            -- At the ceiling «Mostrar más» would be a dead button, so it is
            -- replaced by what the user can actually do about it.
            parts[#parts + 1] = ui.label(rest .. " sesiones más: afiná la búsqueda para verlas",
                                         { icon = "magnifyingglass", color = GREY })
        else
            local next_page = math.min(state.visible * 2, MAX_CARDS, #matching) - shown
            parts[#parts + 1] = ui.list(
                { { label = "Mostrar " .. next_page .. " más",
                    detail = rest .. " restantes", icon = "chevron.down" } },
                { on_select = "show_more" })
        end
    end
    return parts
end

function M.panel_content()
    if state.sessions == nil then reload_data() end

    state.cards = {}

    if state.error then return error_view() end
    if state.view == "detail" and state.selected then return detail_view() end
    return list_view()
end

return M
