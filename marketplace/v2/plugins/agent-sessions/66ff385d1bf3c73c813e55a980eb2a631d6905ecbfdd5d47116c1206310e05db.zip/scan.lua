-- Session discovery for Claude Code and Codex.
--
-- Both agents keep their transcripts as JSONL on disk, so a single python
-- pass can index them: ~/.claude/projects/<encoded-cwd>/<uuid>.jsonl for
-- Claude, ~/.codex/sessions/YYYY/MM/DD/rollout-<ts>-<uuid>.jsonl for Codex.
--
-- Transcripts get large (hundreds of MB across a few hundred files), so the
-- scan never parses a whole file: it reads the head for metadata, the tail
-- for the newest title record, and counts turns with a raw byte scan that
-- skips JSON parsing entirely.

local sh = require("sh")

local M = {}

M.SEP = "\1"

local SCAN_SCRIPT = [==[
python3 - <<'PYEOF'
import os, glob, json, stat

SEP        = chr(1)
HOME       = os.path.expanduser("~")
HEAD_LINES = 400
HEAD_BYTES = 1 << 20
TAIL_BYTES = 256 * 1024
CHUNK      = 1 << 20


def safe_json(line):
    line = line.strip()
    if not line or not line.startswith("{"):
        return None
    try:
        return json.loads(line)
    except Exception:
        return None


def clean(value):
    return (value or "").replace(SEP, " ").replace("\n", " ").replace("\r", " ").strip()


# Counting turns by parsing every record would mean reading ~240 MB of JSON on
# each refresh. Counting the raw marker bytes gives the same number for a
# fraction of the cost; the overlap window keeps markers split across chunk
# boundaries from being missed.
def count_marker(path, marker):
    total, overlap, prev = 0, len(marker) - 1, b""
    try:
        with open(path, "rb") as fh:
            while True:
                chunk = fh.read(CHUNK)
                if not chunk:
                    break
                total += (prev + chunk).count(marker)
                prev = chunk[-overlap:] if overlap else b""
    except Exception:
        return 0
    return total


# The current title lives in the last title record of the file, not the first:
# both agents re-emit it as the conversation evolves.
def tail_lines(path, size):
    try:
        with open(path, "rb") as fh:
            if size > TAIL_BYTES:
                fh.seek(size - TAIL_BYTES)
                fh.readline()
            data = fh.read()
    except Exception:
        return []
    return data.decode("utf-8", "ignore").splitlines()


def head_records(path):
    read = 0
    try:
        with open(path, "r", errors="ignore") as fh:
            for index, line in enumerate(fh):
                read += len(line)
                if index >= HEAD_LINES or read > HEAD_BYTES:
                    break
                record = safe_json(line)
                if record is not None:
                    yield record
    except Exception:
        return


def first_text(content):
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        for block in content:
            if isinstance(block, dict) and block.get("type") in ("text", "input_text"):
                return block.get("text", "")
    return ""


# Agents open a session by injecting context the user never typed: XML-ish
# blocks, and for Codex the whole AGENTS.md delivered as a user-role message.
# Those make a misleading fallback title, so they are skipped.
INJECTED = (
    "<INSTRUCTIONS>", "<environment_context>", "<user_instructions>",
    "<recommended_plugins>", "<system-reminder>", "<command-name>",
    "<local-command-stdout>", "AGENTS.md instructions for",
)


def as_prompt(text):
    text = (text or "").strip()
    if not text or text[0] in "<#":
        return ""
    head = text[:400]
    for marker in INJECTED:
        if marker in head:
            return ""
    return clean(text)[:90]


def decode_project_dir(name):
    candidate = "/" + name.lstrip("-").replace("-", "/")
    return candidate if os.path.isdir(candidate) else ""


def regular_file(path):
    try:
        return stat.S_ISREG(os.lstat(path).st_mode)
    except OSError:
        return False


# Titles are emitted possibly empty: a session with neither a name nor a user
# prompt never got off the ground, and the panel wants to be able to tell.
def emit(agent, sid, path, cwd, title, auto_title, named, branch, mtime, count):
    print(SEP.join([
        agent, sid, path, clean(cwd), clean(title)[:140], clean(auto_title)[:140],
        "1" if named else "0", clean(branch), "%d" % mtime, str(count),
    ]))


def scan_claude():
    root = os.path.join(HOME, ".claude", "projects")
    for project_dir in sorted(glob.glob(os.path.join(root, "*"))):
        if os.path.islink(project_dir) or not os.path.isdir(project_dir):
            continue
        decoded = decode_project_dir(os.path.basename(project_dir))
        for path in glob.glob(os.path.join(project_dir, "*.jsonl")):
            if not regular_file(path):
                continue
            sid = os.path.basename(path)[:-6]
            try:
                size, mtime = os.path.getsize(path), os.path.getmtime(path)
            except Exception:
                continue

            cwd = branch = prompt = ai_title = custom_title = ""
            for record in head_records(path):
                kind = record.get("type")
                if kind == "ai-title" and record.get("aiTitle"):
                    ai_title = record["aiTitle"]
                elif kind == "custom-title" and record.get("customTitle"):
                    custom_title = record["customTitle"]
                elif kind in ("user", "assistant"):
                    cwd = cwd or record.get("cwd") or ""
                    branch = branch or record.get("gitBranch") or ""
                    if not prompt and kind == "user" and not record.get("isMeta"):
                        prompt = as_prompt(first_text((record.get("message") or {}).get("content")))

            for line in tail_lines(path, size):
                if '"ai-title"' in line or '"custom-title"' in line:
                    record = safe_json(line)
                    if not record:
                        continue
                    if record.get("aiTitle"):
                        ai_title = record["aiTitle"]
                    if record.get("customTitle"):
                        custom_title = record["customTitle"]

            emit("claude", sid, path, cwd or decoded or os.path.basename(project_dir),
                 custom_title or ai_title or prompt, ai_title or prompt,
                 bool(custom_title), branch, mtime,
                 count_marker(path, b'"type":"user"'))


# Codex keeps the user-assigned thread name out of the transcript, in a small
# index file rewritten by the CLI.
def codex_names():
    names = {}
    path = os.path.join(HOME, ".codex", "session_index.jsonl")
    try:
        with open(path, "r", errors="ignore") as fh:
            for line in fh:
                record = safe_json(line)
                if not record or not record.get("id"):
                    continue
                name = (record.get("thread_name") or "").strip()
                if name:
                    names[record["id"]] = name
    except Exception:
        pass
    return names


def scan_codex():
    names = codex_names()
    root = os.path.join(HOME, ".codex", "sessions")
    for path in glob.glob(os.path.join(root, "*", "*", "*", "rollout-*.jsonl")):
        if not regular_file(path):
            continue
        try:
            mtime = os.path.getmtime(path)
        except Exception:
            continue

        sid = cwd = prompt = ""
        for record in head_records(path):
            payload = record.get("payload") or {}
            if record.get("type") == "session_meta":
                sid = payload.get("session_id") or payload.get("id") or ""
                cwd = payload.get("cwd") or ""
            elif not prompt and payload.get("type") == "message" and payload.get("role") == "user":
                prompt = as_prompt(first_text(payload.get("content")))
            if sid and cwd and prompt:
                break

        if not sid:
            stem = os.path.basename(path)[len("rollout-"):-len(".jsonl")]
            sid = stem[20:] if len(stem) > 20 else stem

        name = names.get(sid, "")
        emit("codex", sid, path, cwd, name or prompt, prompt, bool(name), "", mtime,
             count_marker(path, b'"role":"user"'))


scan_claude()
scan_codex()
PYEOF
]==]

local function split(line, sep)
    local out, pos = {}, 1
    while true do
        local from, to = line:find(sep, pos, true)
        if not from then
            out[#out + 1] = line:sub(pos)
            return out
        end
        out[#out + 1] = line:sub(pos, from - 1)
        pos = to + 1
    end
end

local function basename(path)
    if not path or path == "" then return "?" end
    local trimmed = path:gsub("(.)/+$", "%1")
    return trimmed:match("([^/]+)$") or trimmed
end

M.basename = basename

-- Paths read better home-relative, the way a shell prompt shows them. The home
-- directory is recovered from the first transcript seen — they all live under
-- ~/.claude or ~/.codex — because the sandbox strips os.getenv.
local home = nil

function M.pretty_path(path)
    if home and path:sub(1, #home + 1) == home .. "/" then
        return "~" .. path:sub(#home + 1)
    end
    return path
end

-- Returns a flat list of sessions, newest first. Grouping is deliberately not
-- done here: the panel shows every session straight away and the project is
-- just another field on the card.
function M.load()
    local raw, err = sh.capture(SCAN_SCRIPT, 30)
    if err then
        return nil, err
    end

    local sessions = {}
    for line in (raw or ""):gmatch("[^\n]+") do
        local f = split(line, M.SEP)
        if #f >= 10 then
            home = home or f[3]:match("^(.*)/%.claude/") or f[3]:match("^(.*)/%.codex/")
            local cwd = f[4]
            sessions[#sessions + 1] = {
                agent      = f[1],
                id         = f[2],
                file       = f[3],
                cwd        = cwd,
                project    = cwd ~= "" and basename(cwd) or "(sin proyecto)",
                title      = f[5],
                auto_title = f[6],
                named      = f[7] == "1",
                branch     = f[8],
                mtime      = tonumber(f[9]) or 0,
                count      = tonumber(f[10]) or 0,
                -- Surfaced so the panel can grey out everything that would put
                -- this id on a command line. ops re-checks it anyway.
                safe_id    = sh.is_session_id(f[2]),
            }
        end
    end

    table.sort(sessions, function(a, b) return a.mtime > b.mtime end)
    return sessions, nil
end

return M
