local M = {}

M.name = "music-matrix"
M.version = "1.0.0"
M.author = "mwerner"
M.description = "Lluvia Matrix sincronizada con el audio del sistema y la canción actual."
M.permissions = { "shell", "audio_capture" }
M.terminal_background = true
M.audio_reactive = true

local last_playing = false
local stopped_checks = 0

local PLAYERS = { "Music", "Spotify" }
local TRACK_SEPARATOR = string.char(31)
local PLAYER_COMMAND = [[/usr/bin/osascript -e 'if application "%s" is running then
  tell application "%s"
    try
      if player state is playing then
        return "playing" & (ASCII character 31) & name of current track & (ASCII character 31) & artist of current track
      end if
    end try
  end tell
end if
return "stopped"']]

local function rain_opacity()
  local value = tonumber(terminalis.storage.get("rain_opacity") or "0.82") or 0.82
  return math.min(1, math.max(0.05, value))
end

local function show_now_playing()
  local value = terminalis.storage.get("show_now_playing")
  -- Default on, while accepting values persisted by older host builds too.
  if value == nil then return true end
  return value == true or value == "true" or value == 1
end

local POSITIONS = {
  ["Inferior derecha"] = "bottom-right",
  ["Inferior izquierda"] = "bottom-left",
  ["Superior derecha"] = "top-right",
  ["Superior izquierda"] = "top-left",
  ["Header"] = "header",
  ["Barra de repositorio"] = "repository-bar",
}

local function track_position()
  local value = terminalis.storage.get("track_position") or "bottom-right"
  for _, position in pairs(POSITIONS) do
    if value == position then return position end
  end
  return "bottom-right"
end

local function position_css(position)
  local inset = "28px"
  if position == "header" or position == "repository-bar" then return "display:none" end
  if position == "bottom-left" then return "left:" .. inset .. ";bottom:34px;text-align:left" end
  if position == "top-right" then return "right:" .. inset .. ";top:34px" end
  if position == "top-left" then return "left:" .. inset .. ";top:34px;text-align:left" end
  return "right:" .. inset .. ";bottom:34px"
end

local function position_label(position)
  for label, value in pairs(POSITIONS) do
    if value == position then return label end
  end
  return "Inferior derecha"
end

local function js_string(value)
  return (value or ""):gsub("\\", "\\\\")
                        :gsub("'", "\\'")
                        :gsub("%c", " ")
                        :gsub("\226\128\168", "\\u2028")
                        :gsub("\226\128\169", "\\u2029")
                        :gsub("</", "<\\/")
end

local function query(command)
  local output, err = terminalis.shell(command)
  if err then return nil end
  if not output or output == "" then return nil end
  local pattern = "^([^" .. TRACK_SEPARATOR .. "]+)" .. TRACK_SEPARATOR
               .. "([^" .. TRACK_SEPARATOR .. "]*)" .. TRACK_SEPARATOR .. "(.*)$"
  local state, title, artist = output:match(pattern)
  if state == "playing" then return true, title or "", artist or "" end
  if output:match("^stopped%s*$") then return false, "", "" end
  return nil
end

local function music()
  local saw_stopped = false
  for _, player in ipairs(PLAYERS) do
    local playing, title, artist = query(string.format(PLAYER_COMMAND, player, player))
    if playing then return playing, title, artist end
    if playing == false then saw_stopped = true end
  end
  if saw_stopped then return false, "", "" end
  return nil
end

local function safe_hex_color(value)
  if type(value) == "string" and value:match("^#%x%x%x%x%x%x$") then return value end
  return nil
end

local function theme_color()
  local theme = terminalis.theme()
  return safe_hex_color(theme and theme.accent) or "#00ff41"
end

local function publish_music(playing, title, artist)
  if not show_now_playing() or not playing then
    terminalis.status.clear()
    terminalis.repository_status.clear()
    return
  end
  local position = track_position()
  local text = "♫ " .. title
  local options = { icon = "music.note", color = theme_color() }
  if position == "header" then
    terminalis.status.set(text, options)
    terminalis.repository_status.clear()
  elseif position == "repository-bar" then
    terminalis.repository_status.set(text, options)
    terminalis.status.clear()
  else
    terminalis.status.clear()
    terminalis.repository_status.clear()
  end
end

local function page(playing, title, artist)
  local color = theme_color()
  local opacity = rain_opacity()
  local hud_position = position_css(track_position())
  local hud_display = show_now_playing() and "" or "display:none;"
  local initial_playing = show_now_playing() and playing == true
  return [[<!doctype html><html><head><meta charset="utf-8"><style>
  *{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:transparent}
  #rain{position:fixed;inset:0;width:100%;height:100%;pointer-events:none;opacity:]] .. string.format("%.2f", opacity) .. [[}
  #hud{position:fixed;]] .. hud_display .. hud_position .. [[;max-width:34vw;font:10px ui-monospace,Menlo,monospace;letter-spacing:.08em;color:]] .. color .. [[;text-shadow:0 0 10px ]] .. color .. [[88;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  #artist{opacity:.58;margin-top:5px}
  </style></head><body><canvas id="rain"></canvas><div id="hud"><div id="track"></div><div id="artist"></div></div><script>
  const canvas=document.getElementById('rain'),ctx=canvas.getContext('2d');let bands=[];
  const step=7,fontSize=10,trail=16,baseSpeed=3.4,minSpeed=.22,spectrumTTL=250;
  let cols=[];const chars='ｦｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789ABCDEF';
  const char=()=>chars[(Math.random()*chars.length)|0];
  const makeColumn=(h)=>({headY:-Math.random()*(h+trail*fontSize),speed:.4+Math.random(),chars:Array.from({length:trail+1},char),pause:0});
  function resize(){canvas.width=innerWidth;canvas.height=innerHeight;cols=[]}addEventListener('resize',resize);resize();
  let lastSpectrumAt=0;window.terminalisAudioSpectrum=(next)=>{bands=Array.isArray(next)?next:[];lastSpectrumAt=performance.now()};
  window.terminalisNowPlaying=(playing,title,artist)=>{const hud=document.getElementById('hud');hud.style.display=playing?'':'none';document.getElementById('track').textContent=playing?'♫ '+title:'';document.getElementById('artist').textContent=playing?artist:''};
  window.terminalisNowPlaying(]] .. tostring(initial_playing) .. [[,']] .. js_string(title) .. [[',']] .. js_string(artist) .. [[');
  function frame(t){const w=canvas.width,h=canvas.height,count=Math.ceil(w/step),activeBands=performance.now()-lastSpectrumAt<spectrumTTL?bands:[];
    if(cols.length!==count)cols=Array.from({length:count},()=>makeColumn(h));ctx.clearRect(0,0,w,h);ctx.font='bold '+fontSize+'px monospace';ctx.textAlign='center';ctx.textBaseline='top';
    for(let i=0;i<count;i++){const col=cols[i],v=activeBands.length?(activeBands[(i*activeBands.length/count)|0]||0):0;if(col.pause>0){col.pause--;continue}col.headY+=col.speed*(minSpeed+v*baseSpeed);if(col.headY-trail*fontSize>h){col.headY=-(trail+1)*fontSize-Math.random()*h*.4;col.chars=Array.from({length:trail+1},char);col.pause=Math.random()<.45?15+((Math.random()*75)|0):0;continue}col.chars[0]=char();for(let j=1;j<=trail;j++){if(Math.random()<.18*(1-j/(trail+1)))col.chars[j]=char()}for(let j=0;j<=trail;j++){const y=col.headY-j*fontSize;if(y<-fontSize||y>h)continue;const fade=1-j/(trail+1);ctx.fillStyle=j===0?'rgba(245,255,245,'+(.65+v*.35)+')':'rgba(0,255,65,'+Math.max(.02+v*.06,fade*fade*fade*(.55+v*.45))+')';ctx.fillText(col.chars[j],i*step+3,y)}}
    requestAnimationFrame(frame)}requestAnimationFrame(frame);
  </script></body></html>]]
end

function M.background_content()
  local playing, title, artist = music()
  publish_music(playing, title, artist)
  return ui.webview(page(playing, title, artist))
end

function M.on_load() terminalis.background.show() end
function M.on_unload()
  terminalis.background.hide()
  terminalis.status.clear()
  terminalis.repository_status.clear()
end

local function refresh_music()
  if not show_now_playing() then
    publish_music(false, "", "")
    terminalis.background.eval("window.terminalisNowPlaying(false,'','')")
    return
  end
  local playing, title, artist = music()
  -- A player may be briefly unavailable while changing tracks. Preserve the
  -- last confirmed metadata instead of replacing it with a false standby state.
  if playing == nil then return end
  if not playing and last_playing then
    stopped_checks = stopped_checks + 1
    if stopped_checks < 2 then return end
  else
    stopped_checks = 0
  end
  last_playing = playing
  publish_music(playing, title, artist)
  terminalis.background.eval("window.terminalisNowPlaying(" .. tostring(playing) .. ",'" .. js_string(title) .. "','" .. js_string(artist) .. "')")
end

function M.on_tick() refresh_music() end

function M.settings_content()
  local settings = {
    ui.slider("Opacidad de la lluvia", {
      value = rain_opacity(), min = 0.05, max = 1, step = 0.05,
      on_change = "set_rain_opacity",
    }),
    ui.separator(),
    ui.toggle("Mostrar canción actual", {
      value = show_now_playing(), icon = "music.note",
      on_change = "set_show_now_playing",
    }),
  }
  if show_now_playing() then
    table.insert(settings, ui.picker("Ubicación de canción", {
      options = { "Inferior derecha", "Inferior izquierda", "Superior derecha", "Superior izquierda", "Header", "Barra de repositorio" },
      value = position_label(track_position()), on_change = "set_track_position",
    }))
  end
  return settings
end

function M.set_rain_opacity(ctx)
  local value = tonumber(ctx.value) or 0.82
  terminalis.storage.set("rain_opacity", math.min(1, math.max(0.05, value)))
  terminalis.background.reload()
end

function M.set_track_position(ctx)
  local position = POSITIONS[ctx.value] or "bottom-right"
  terminalis.storage.set("track_position", position)
  local playing, title, artist = music()
  publish_music(playing, title, artist)
  terminalis.background.reload()
end

function M.set_show_now_playing(ctx)
  local enabled = ctx.value == "true"
  terminalis.storage.set("show_now_playing", enabled)
  if not enabled then
    last_playing, stopped_checks = false, 0
    publish_music(false, "", "")
  end
  terminalis.background.reload()
end

return M
